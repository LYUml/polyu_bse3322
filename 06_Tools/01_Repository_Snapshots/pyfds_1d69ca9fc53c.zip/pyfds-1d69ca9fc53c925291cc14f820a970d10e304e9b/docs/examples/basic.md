# Basic Examples

Simple simulations to get started with PyFDS.

## Simple Room Fire

A 5m × 5m room with a 1m² fire source.

```python
from pyfds.core.namelists import Simulation, Time, Mesh, Surface, Obstruction, Device
from pyfds.core.geometry import Bounds3D, Grid3D, Point3D

# Create simulation
sim = Simulation(chid='room_fire', title='Simple Room Fire')

# Time: 10 minutes
sim.add(Time(t_end=600.0))

# Domain: 5m × 5m × 2.5m room, 0.1m cells
sim.add(Mesh(ijk=Grid3D.of(50, 50, 25), xb=Bounds3D.of(0, 5, 0, 5, 0, 2.5)))

# Fire: 1m × 1m burner, 1000 kW/m²
sim.add(Surface(id='BURNER', hrrpua=1000.0, color='RED'))
sim.add(Obstruction(xb=Bounds3D.of(2, 3, 2, 3, 0, 0.1), surf_ids=('BURNER', 'INERT', 'INERT')))

# Measurements
sim.add(Device(id='TEMP_CEILING', quantity='TEMPERATURE', xyz=Point3D.of(2.5, 2.5, 2.4)))
sim.add(Device(id='TEMP_FLOOR', quantity='TEMPERATURE', xyz=Point3D.of(2.5, 2.5, 0.1)))

# Write FDS file
sim.write('room_fire.fds')
```

**Features Demonstrated:**
- Basic simulation setup
- Simple mesh definition
- Fire surface creation
- Temperature measurement with Point3D coordinates

**Expected Results:**
- Peak ceiling temperature: ~300-400°C
- Smoke layer forms at ~1.5m height
- Total HRR: 1000 kW (1 MW)

## Corridor Fire

A 20m long corridor with fire at one end.

```python
from pyfds.core.namelists import Simulation, Time, Mesh, Surface, Obstruction, Device
from pyfds.core.geometry import Bounds3D, Grid3D, Point3D

sim = Simulation(chid='corridor', title='Corridor Fire')

sim.add(Time(t_end=300.0))

# Long narrow corridor: 20m × 2m × 2.4m
sim.add(Mesh(ijk=Grid3D.of(100, 10, 12), xb=Bounds3D.of(0, 20, 0, 2, 0, 2.4)))

# Fire at one end
sim.add(Surface(id='FIRE', hrrpua=500.0, color='ORANGE'))
sim.add(Obstruction(xb=Bounds3D.of(1, 2, 0.5, 1.5, 0, 0.1), surf_ids=('FIRE', 'INERT', 'INERT')))

# Temperature array along corridor
for i, x in enumerate([2, 5, 10, 15, 18]):
    sim.add(Device(id=f'TEMP_{i+1}', quantity='TEMPERATURE', xyz=Point3D.of(x, 1, 2.2)))

sim.write('corridor.fds')
```

**Features:**
- Elongated domain
- Temperature gradient
- Smoke propagation

## Growing Fire

Fire that increases in intensity over time.

```python
from pyfds.core.namelists import Simulation, Time, Mesh, Surface, Obstruction, Device, Ramp
from pyfds.core.geometry import Bounds3D, Grid3D, Point3D

sim = Simulation(chid='growing_fire', title='Growing Fire')

sim.add(Time(t_end=300.0))
sim.add(Mesh(ijk=Grid3D.of(40, 40, 20), xb=Bounds3D.of(0, 4, 0, 4, 0, 2)))

# Define fire growth (0 to 100% over 180 seconds)
sim.add(Ramp(
    id='GROWTH',
    t=[0, 60, 120, 180],
    f=[0.0, 0.2, 0.6, 1.0]
))

# Fire with time-varying HRR
sim.add(Surface(
    id='GROWING',
    hrrpua=1500.0,
    ramp_q='GROWTH',
    color='RED'
))

sim.add(Obstruction(xb=Bounds3D.of(1.5, 2.5, 1.5, 2.5, 0, 0.1), surf_ids=('GROWING', 'INERT', 'INERT')))

# Monitor HRR and temperature
sim.add(Device(id='TEMP', quantity='TEMPERATURE', xyz=Point3D.of(2, 2, 1.8)))

sim.write('growing_fire.fds')
```

**Features:**
- Time-varying fire using RAMP
- Growing HRR profile
- Real-time temperature response

## Room with Door

Room fire with an open door.

```python
from pyfds.core.namelists import Simulation, Time, Mesh, Surface, Obstruction, Device, Vent
from pyfds.core.geometry import Bounds3D, Grid3D, Point3D

sim = Simulation(chid='room_door', title='Room with Door')

sim.add(Time(t_end=300.0))
sim.add(Mesh(ijk=Grid3D.of(50, 40, 25), xb=Bounds3D.of(0, 5, 0, 4, 0, 2.5)))

# Fire
sim.add(Surface(id='FIRE', hrrpua=1000.0))
sim.add(Obstruction(xb=Bounds3D.of(2, 3, 1.5, 2.5, 0, 0.1), surf_ids=('FIRE', 'INERT', 'INERT')))

# Walls (with door opening)
sim.add(Surface(id='WALL', matl_id='GYPSUM', thickness=0.013))
sim.add(Obstruction(xb=Bounds3D.of(0, 0.2, 0, 4, 0, 2.5), surf_ids=('WALL', 'INERT', 'INERT')))  # West
sim.add(Obstruction(xb=Bounds3D.of(4.8, 5, 0, 4, 0, 2.5), surf_ids=('WALL', 'INERT', 'INERT')))  # East
sim.add(Obstruction(xb=Bounds3D.of(0, 5, 0, 0.2, 0, 2.5), surf_ids=('WALL', 'INERT', 'INERT')))  # South

# North wall with door
sim.add(Obstruction(xb=Bounds3D.of(0, 2, 3.8, 4, 0, 2.5), surf_ids=('WALL', 'INERT', 'INERT')))      # Left
sim.add(Obstruction(xb=Bounds3D.of(3, 5, 3.8, 4, 0, 2.5), surf_ids=('WALL', 'INERT', 'INERT')))      # Right
sim.add(Obstruction(xb=Bounds3D.of(2, 3, 3.8, 4, 2.1, 2.5), surf_ids=('WALL', 'INERT', 'INERT')))    # Above

# Door opening
sim.add(Vent(xb=Bounds3D.of(2, 3, 3.8, 3.8, 0, 2.1), surf_id='OPEN'))

# Measurements
sim.add(Device(id='TEMP_INSIDE', quantity='TEMPERATURE', xyz=Point3D.of(2.5, 2, 2.2)))
sim.add(Device(id='TEMP_DOOR', quantity='TEMPERATURE', xyz=Point3D.of(2.5, 3.8, 1.0)))
sim.add(Device(id='VEL_DOOR', quantity='VELOCITY', xyz=Point3D.of(2.5, 3.8, 1.0)))

sim.write('room_door.fds')
```

**Features:**
- Room geometry with walls
- Door opening using VENT
- Airflow measurements
- Material properties

## Multiple Fires

Two separate fires in the same space.

```python
from pyfds.core.namelists import Simulation, Time, Mesh, Surface, Obstruction, Device
from pyfds.core.geometry import Bounds3D, Grid3D, Point3D

sim = Simulation(chid='two_fires', title='Two Fire Sources')

sim.add(Time(t_end=300.0))
sim.add(Mesh(ijk=Grid3D.of(80, 40, 25), xb=Bounds3D.of(0, 8, 0, 4, 0, 2.5)))

# Two different fire intensities
sim.add(Surface(id='FIRE_A', hrrpua=750.0, color='ORANGE'))
sim.add(Surface(id='FIRE_B', hrrpua=1250.0, color='RED'))

# Fire A (smaller)
sim.add(Obstruction(xb=Bounds3D.of(1.5, 2.5, 1.5, 2.5, 0, 0.1), surf_ids=('FIRE_A', 'INERT', 'INERT')))

# Fire B (larger)
sim.add(Obstruction(xb=Bounds3D.of(5.5, 6.5, 1.5, 2.5, 0, 0.1), surf_ids=('FIRE_B', 'INERT', 'INERT')))

# Temperature measurements above each fire
sim.add(Device(id='TEMP_A', quantity='TEMPERATURE', xyz=Point3D.of(2, 2, 2.2)))
sim.add(Device(id='TEMP_B', quantity='TEMPERATURE', xyz=Point3D.of(6, 2, 2.2)))

# Center of room
sim.add(Device(id='TEMP_CENTER', quantity='TEMPERATURE', xyz=Point3D.of(4, 2, 2.2)))

sim.write('two_fires.fds')
```

**Features:**
- Multiple fire sources
- Different fire intensities
- Thermal interaction

## Quick Test Simulation

Fast-running test for development.

```python
from pyfds.core.namelists import Simulation, Time, Mesh, Surface, Obstruction, Device
from pyfds.core.geometry import Bounds3D, Grid3D, Point3D

# Coarse mesh, short time for quick testing
sim = Simulation(chid='quick_test', title='Quick Test')

sim.add(Time(t_end=30.0))  # Only 30 seconds
sim.add(Mesh(ijk=Grid3D.of(20, 20, 10), xb=Bounds3D.of(0, 2, 0, 2, 0, 1)))  # Coarse cells

# Simple fire
sim.add(Surface(id='FIRE', hrrpua=500.0))
sim.add(Obstruction(xb=Bounds3D.of(0.75, 1.25, 0.75, 1.25, 0, 0.05), surf_ids=('FIRE', 'INERT', 'INERT')))

# Basic measurement
sim.add(Device(id='TEMP', quantity='TEMPERATURE', xyz=Point3D.of(1, 1, 0.9)))

sim.write('quick_test.fds')

# Run immediately (requires FDS)
# results = sim.run(n_threads=4)
# print(f"Peak temp: {results.devices['TEMP'].max():.1f} °C")
```

**Features:**
- Fast execution (~30 seconds)
- Suitable for testing and debugging
- Can iterate quickly

## Running Examples

All examples can be run directly:

```bash
# Create FDS file
python room_fire.py

# Or run with execution
python -c "
from room_fire import sim
results = sim.run(n_threads=4)
print(f'Simulation complete: {results.hrr[\"HRR\"].max():.0f} kW peak')
"
```

## Next Steps

- [Advanced Examples](advanced.md) - More complex scenarios
- [Special Applications](special.md) - Specialized simulations
- [Parametric Studies](parametric.md) - Multiple simulations

---

[Advanced Examples →](advanced.md){ .md-button .md-button--primary }
