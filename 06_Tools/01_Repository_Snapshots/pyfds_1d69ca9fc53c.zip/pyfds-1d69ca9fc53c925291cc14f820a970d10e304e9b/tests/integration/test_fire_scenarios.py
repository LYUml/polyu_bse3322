"""Integration tests for Stage 1 features.

Tests real-world fire simulation scenarios using SURF, DEVC, REAC, and MESH enhancements.
"""

from pyfds.builders import ReactionBuilder
from pyfds.core.geometry import Bounds3D, Grid3D, Point3D
from pyfds.core.namelists import Device, Mesh, Reaction, Surface


class TestFireWithSprinklerControl:
    """Test fire scenario with sprinkler activation control."""

    def test_fire_surface_with_ramped_hrr(self):
        """Test fire surface with time-ramped heat release rate."""
        fire = Surface(id="FIRE", hrrpua=1000.0, ramp_q="t2_growth", emissivity=0.9, color="ORANGE")

        assert fire.id == "FIRE"
        assert fire.hrrpua == 1000.0
        assert fire.ramp_q == "t2_growth"
        assert fire.emissivity == 0.9
        assert fire.color == "ORANGE"

        fds_output = fire.to_fds()
        assert "FIRE" in fds_output
        assert "1000" in fds_output or "1000.0" in fds_output
        assert "t2_growth" in fds_output
        assert "0.9" in fds_output

    def test_sprinkler_with_control_logic(self):
        """Test sprinkler device with temperature-based control."""
        sprinkler = Device(
            id="SPRINK1",
            quantity="SPRINKLER_LINK_TEMPERATURE",
            setpoint=74.0,
            trip_direction=1,
            latch=True,
            delay=2.0,
            xyz=Point3D.of(5.0, 5.0, 3.0),
            prop_id="STANDARD_SPRINKLER",
        )

        assert sprinkler.id == "SPRINK1"
        assert sprinkler.quantity == "SPRINKLER_LINK_TEMPERATURE"
        assert sprinkler.setpoint == 74.0
        assert sprinkler.trip_direction == 1
        assert sprinkler.latch is True
        assert sprinkler.delay == 2.0
        assert sprinkler.xyz == Point3D.of(5.0, 5.0, 3.0)

        fds_output = sprinkler.to_fds()
        assert "SPRINK1" in fds_output
        assert "SPRINKLER_LINK_TEMPERATURE" in fds_output
        assert "74" in fds_output or "74.0" in fds_output
        assert "2" in fds_output or "2.0" in fds_output

    def test_complete_fire_sprinkler_scenario(self):
        """Test complete scenario: fire with sprinkler and temperature monitoring."""
        # Fire source
        fire_surf = Surface(
            id="BURNER",
            hrrpua=500.0,
            ramp_q="fire_ramp",
            ignition_temperature=250.0,
            burn_away=True,
            emissivity=0.85,
        )

        # Sprinkler detector
        sprinkler = Device(
            id="SPRINK",
            quantity="SPRINKLER_LINK_TEMPERATURE",
            setpoint=74.0,
            latch=True,
            xyz=Point3D.of(5.0, 5.0, 2.8),
        )

        # Temperature sensor
        temp_sensor = Device(
            id="TEMP_CEILING",
            quantity="TEMPERATURE",
            xyz=Point3D.of(5.0, 5.0, 2.9),
            time_history=True,
        )

        # Verify all components created successfully
        assert isinstance(fire_surf, Surface)
        assert isinstance(sprinkler, Device)
        assert isinstance(temp_sensor, Device)

        # Verify control logic
        assert sprinkler.setpoint == 74.0
        assert temp_sensor.time_history is True


class TestMultiMeshParallelSimulation:
    """Test multi-mesh parallel fire simulation."""

    def test_single_mesh_with_mpi(self):
        """Test single mesh with MPI assignment."""
        mesh = Mesh(
            id="MESH1",
            xb=Bounds3D.of(0, 10, 0, 10, 0, 3),
            ijk=Grid3D.of(50, 50, 15),
            mpi_process=0,
        )

        assert mesh.id == "MESH1"
        assert mesh.mpi_process == 0
        assert mesh.xb == Bounds3D.of(0, 10, 0, 10, 0, 3)
        assert mesh.ijk == Grid3D.of(50, 50, 15)

    def test_multi_mesh_array(self):
        """Test array of meshes for parallel processing."""
        meshes = []
        for i in range(4):
            mesh = Mesh(
                id=f"MESH{i}",
                xb=Bounds3D.of(i * 10, (i + 1) * 10, 0, 10, 0, 3),
                ijk=Grid3D.of(50, 50, 15),
                mpi_process=i,
            )
            meshes.append(mesh)

        assert len(meshes) == 4
        assert all(m.mpi_process is not None for m in meshes)
        assert meshes[0].xb == Bounds3D.of(0, 10, 0, 10, 0, 3)
        assert meshes[3].xb == Bounds3D.of(30, 40, 0, 10, 0, 3)

    def test_mesh_with_stability_control(self):
        """Test mesh with valid FDS MESH parameters.

        Note: Stability parameters like CFL_MAX, VN_MAX belong on MISC namelist,
        not MESH. This test now uses actual MESH parameters per FDS User Guide.
        """
        mesh = Mesh(
            id="FINE_MESH",
            xb=Bounds3D.of(0, 10, 0, 10, 0, 3),
            ijk=Grid3D.of(100, 100, 30),
            check_mesh_alignment=True,
            color="BLUE",
        )

        assert mesh.id == "FINE_MESH"
        assert mesh.check_mesh_alignment is True
        assert mesh.color == "BLUE"

        fds_output = mesh.to_fds()
        assert "FINE_MESH" in fds_output
        assert "CHECK_MESH_ALIGNMENT" in fds_output


class TestStatisticalTemperatureMonitoring:
    """Test statistical averaging and monitoring."""

    def test_volume_average_temperature(self):
        """Test device with volume averaging statistics."""
        avg_temp = Device(
            id="AVG_TEMP",
            quantity="TEMPERATURE",
            spatial_statistic="MEAN",
            statistics_start=10.0,
            xb=Bounds3D.of(0, 10, 0, 10, 0, 3),
        )

        assert avg_temp.id == "AVG_TEMP"
        assert avg_temp.quantity == "TEMPERATURE"
        assert avg_temp.spatial_statistic == "MEAN"
        assert avg_temp.statistics_start == 10.0
        assert avg_temp.xb == Bounds3D.of(0, 10, 0, 10, 0, 3)

        fds_output = avg_temp.to_fds()
        assert "MEAN" in fds_output
        assert "10" in fds_output or "10.0" in fds_output

    def test_multiple_statistical_devices(self):
        """Test multiple devices with different statistics."""
        devices = []

        # Mean temperature
        devices.append(
            Device(
                id="MEAN_TEMP",
                quantity="TEMPERATURE",
                spatial_statistic="MEAN",
                xb=Bounds3D.of(0, 5, 0, 5, 0, 3),
            )
        )

        # Max temperature
        devices.append(
            Device(
                id="MAX_TEMP",
                quantity="TEMPERATURE",
                spatial_statistic="MAX",
                xb=Bounds3D.of(0, 5, 0, 5, 0, 3),
            )
        )

        # Min temperature
        devices.append(
            Device(
                id="MIN_TEMP",
                quantity="TEMPERATURE",
                spatial_statistic="MIN",
                xb=Bounds3D.of(0, 5, 0, 5, 0, 3),
            )
        )

        assert len(devices) == 3
        assert devices[0].spatial_statistic == "MEAN"
        assert devices[1].spatial_statistic == "MAX"
        assert devices[2].spatial_statistic == "MIN"

    def test_temporal_and_spatial_statistics(self):
        """Test device with both temporal and spatial statistics."""
        devc = Device(
            id="COMPLEX_STAT",
            quantity="VELOCITY",
            temporal_statistic="RMS",
            spatial_statistic="MAX",
            xb=Bounds3D.of(0, 10, 0, 10, 0, 3),
        )

        assert devc.temporal_statistic == "RMS"
        assert devc.spatial_statistic == "MAX"


class TestExtinctionAndSuppressionModeling:
    """Test combustion extinction and suppression features."""

    def test_reaction_with_extinction(self):
        """Test reaction with extinction parameters.

        Note: EXTINCTION_MODEL is a MISC parameter, not REAC.
        REAC has CRITICAL_FLAME_TEMPERATURE and LOWER_OXYGEN_LIMIT.
        """
        reac = (
            ReactionBuilder()
            .fuel("PROPANE")
            .with_extinction(critical_temp=1200.0)
            .with_extinction_limit(0.12)
            .radiative_fraction(0.35)
            .build()
        )

        assert reac.fuel == "PROPANE"
        assert reac.critical_flame_temperature == 1200.0
        assert reac.lower_oxygen_limit == 0.12
        assert reac.radiative_fraction == 0.35

        fds_output = reac.to_fds()
        assert "PROPANE" in fds_output
        assert "CRITICAL_FLAME_TEMPERATURE=1200" in fds_output
        assert "LOWER_OXYGEN_LIMIT=0.12" in fds_output

    def test_reaction_with_lower_oxygen_limit(self):
        """Test reaction with lower oxygen limit for extinction.

        Note: Suppression parameters are not on REAC namelist.
        """
        reac = ReactionBuilder().fuel("WOOD").with_extinction_limit(0.10).soot_yield(0.015).build()

        assert reac.fuel == "WOOD"
        assert reac.lower_oxygen_limit == 0.10
        assert reac.soot_yield == 0.015

        fds_output = reac.to_fds()
        assert "WOOD" in fds_output
        assert "LOWER_OXYGEN_LIMIT=0.1" in fds_output

    def test_reaction_with_species_stoichiometry(self):
        """Test reaction with species stoichiometry."""
        reac = (
            ReactionBuilder()
            .fuel("METHANE")
            .with_species_stoichiometry(["CO2", "H2O"], [1.0, 2.0])
            .radiative_fraction(0.30)
            .build()
        )

        assert reac.spec_id_nu == ["CO2", "H2O"]
        assert reac.nu == [1.0, 2.0]

    def test_reaction_with_two_step_chemistry(self):
        """Test reaction with two-step chemistry.

        Note: TAU_CHEM and TAU_FLAME are COMB namelist parameters, not REAC.
        REAC has N_SIMPLE_CHEMISTRY_REACTIONS for two-step chemistry.
        """
        reac = ReactionBuilder().fuel("PROPANE").with_two_step_chemistry(co_fraction=0.5).build()

        assert reac.n_simple_chemistry_reactions == 2
        assert reac.fuel_c_to_co_fraction == 0.5

    def test_reaction_with_non_ideal_hoc(self):
        """Test reaction with non-ideal heat of combustion."""
        reac = ReactionBuilder().fuel("ETHANOL").use_non_ideal_hoc().build()

        assert reac.ideal is False


class TestCylindricalMesh:
    """Test cylindrical coordinate mesh."""

    def test_cylindrical_mesh_creation(self):
        """Test creation of cylindrical coordinate mesh."""
        mesh = Mesh(
            xb=Bounds3D.of(0, 1, 0, 1, 0, 3),
            ijk=Grid3D.of(50, 50, 100),
            cylindrical=True,
        )

        assert mesh.cylindrical is True
        assert mesh.xb == Bounds3D.of(0, 1, 0, 1, 0, 3)

        fds_output = mesh.to_fds()
        assert "CYLINDRICAL" in fds_output or "cylindrical" in fds_output.lower()


class TestDeviceOrientation:
    """Test device orientation features."""

    def test_device_with_orientation(self):
        """Test device with custom orientation."""
        devc = Device(
            id="ORIENTED_SENSOR",
            quantity="VELOCITY",
            orientation=(0.0, 0.0, 1.0),
            rotation=45.0,
            xyz=Point3D.of(5.0, 5.0, 1.5),
        )

        assert devc.orientation == (0.0, 0.0, 1.0)
        assert devc.rotation == 45.0


class TestComplexFireScenario:
    """Test complex integrated fire scenario."""

    def test_compartment_fire_with_full_instrumentation(self):
        """Test complete compartment fire with all Stage 1 features."""
        # Mesh
        mesh = Mesh(
            id="ROOM",
            xb=Bounds3D.of(0, 6, 0, 4, 0, 3),
            ijk=Grid3D.of(60, 40, 30),
        )

        # Fire surface with ignition
        fire = Surface(
            id="FIRE",
            hrrpua=750.0,
            ramp_q="t2_medium",
            ignition_temperature=300.0,
            burn_away=True,
            emissivity=0.9,
            absorptivity=0.85,
            backing="INSULATED",
        )

        # Reaction with extinction
        reaction = (
            ReactionBuilder()
            .fuel("POLYURETHANE")
            .with_extinction("EXTINCTION 1", critical_temp=1100.0)
            .radiative_fraction(0.30)
            .yields(soot=0.10, co=0.04)
            .build()
        )

        # Sprinkler
        sprinkler = Device(
            id="SPRINK",
            quantity="SPRINKLER_LINK_TEMPERATURE",
            setpoint=74.0,
            trip_direction=1,
            latch=True,
            xyz=Point3D.of(3.0, 2.0, 2.8),
        )

        # Temperature monitoring
        temp_ceiling = Device(
            id="TEMP_CEILING_AVG",
            quantity="TEMPERATURE",
            spatial_statistic="MEAN",
            statistics_start=5.0,
            xb=Bounds3D.of(0, 6, 0, 4, 2.5, 3.0),
        )

        # Verify all components
        assert isinstance(mesh, Mesh)
        assert isinstance(fire, Surface)
        assert isinstance(reaction, Reaction)
        assert isinstance(sprinkler, Device)
        assert isinstance(temp_ceiling, Device)

        # Verify key properties
        assert mesh.id == "ROOM"
        assert fire.ignition_temperature == 300.0
        assert fire.burn_away is True
        assert reaction.critical_flame_temperature == 1100.0
        assert sprinkler.setpoint == 74.0
        assert temp_ceiling.spatial_statistic == "MEAN"

        # Verify FDS output generation
        assert all(obj.to_fds() for obj in [mesh, fire, reaction, sprinkler, temp_ceiling])


class TestCoreNamelistCreation:
    """Test that core namelist classes work correctly."""

    def test_simple_surf_creation(self):
        """Test that simple SURF creation works."""
        surf = Surface(id="SIMPLE", hrrpua=500.0, color="RED")
        assert surf.id == "SIMPLE"
        assert surf.hrrpua == 500.0

    def test_simple_devc_creation(self):
        """Test that simple DEVC creation works."""
        devc = Device(id="TEMP", quantity="TEMPERATURE", xyz=Point3D.of(5, 5, 2))
        assert devc.id == "TEMP"
        assert devc.quantity == "TEMPERATURE"

    def test_simple_mesh_creation(self):
        """Test that simple MESH creation works."""
        mesh = Mesh(ijk=Grid3D.of(50, 50, 25), xb=Bounds3D.of(0, 10, 0, 10, 0, 5))
        assert mesh.ijk == Grid3D.of(50, 50, 25)

    def test_simple_reaction_creation(self):
        """Test that simple REAC creation works."""
        reac = Reaction(fuel="PROPANE")
        assert reac.fuel == "PROPANE"
