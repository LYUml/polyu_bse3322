# Tests for core validators
