from typing import Iterable, List, Union

from fdsreader.devc import Device
from fdsreader.utils.data import FDSDataCollection


class DeviceCollection(FDSDataCollection):
    """Collection of :class:`Device` objects. Offers additional functionality for working on devices using pandas."""

    def __init__(self, *devices: Iterable[Device]):
        super().__init__(*devices)

    def __getitem__(self, key) -> Union[Device, List[Device]]:
        if isinstance(key, int):
            return self._elements[key]
        else:
            devc = next(
                (
                    devc
                    for devc in self._elements
                    if (devc.id == key if isinstance(devc, Device) else devc[0].id == key)
                ),
                None,
            )
            if devc is None:
                raise KeyError(f"No device found with id '{key}'")
            return devc

    def __contains__(self, value: Union[Device, str]):
        id_matching = any(
            (devc.id == value if isinstance(devc, Device) else devc[0].id == value) for devc in self._elements
        )
        return value in self._elements or id_matching

    def clear_cache(self):
        """Remove all data from the internal cache that has been loaded so far to free memory."""
        for devc in self._elements:
            if isinstance(devc, Device):
                devc.clear_cache()
            elif isinstance(devc, list):
                for list_devc in devc:
                    list_devc.clear_cache()

    def to_pandas_dataframe(self):
        """Returns a pandas DataFrame with device-IDs as column names and device data as column values."""
        import pandas as pd

        data = dict()
        for devc in self:
            if isinstance(devc, Device):
                data[devc.id] = devc.data
            elif isinstance(devc, list):
                # It might be the case that there are multiple devices with the same name
                for i, list_devc in enumerate(devc):
                    data[list_devc.id + "_" + str(i)] = list_devc.data
        return pd.DataFrame(data)
