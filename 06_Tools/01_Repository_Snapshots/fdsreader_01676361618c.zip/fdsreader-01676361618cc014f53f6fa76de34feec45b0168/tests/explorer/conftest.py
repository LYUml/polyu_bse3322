"""Fixtures for the explorer tests.

The cases are written from scratch rather than committed as binary fixtures, so the tests
stay small and readable and do not depend on an FDS build.
"""

import csv

import numpy as np
import pytest


@pytest.fixture
def tiny_case(tmp_path):
    """A simulation with devices and an HRR file, written out on the fly."""
    root = tmp_path / "tiny"
    root.mkdir()

    (root / "tiny.smv").write_text(
        "CHID\n tiny\n\n"
        "CSVF\n devc\n tiny_devc.csv\n\n"
        "CSVF\n hrr\n tiny_hrr.csv\n\n"
        "DEVICE\n TC_1 % TEMPERATURE\n 1.0 0.0 1.0 0.0 0.0 1.0\n\n"
        "DEVICE\n TC_2 % TEMPERATURE\n 2.0 0.0 2.0 0.0 0.0 1.0\n\n"
        "DEVICE_ACT\n 2 5.00 1\n"
    )

    times = np.arange(0.0, 10.5, 0.5)
    with open(root / "tiny_devc.csv", "w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["s", "C", "C"])
        writer.writerow(["Time", "TC_1", "TC_2"])
        for t, a, b in zip(times, 20 + 8 * times, 20 + 3 * times):
            writer.writerow([f"{t:.4f}", f"{a:.4f}", f"{b:.4f}"])

    with open(root / "tiny_hrr.csv", "w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["s", "kW"])
        writer.writerow(["Time", "HRR"])
        for t in times:
            writer.writerow([f"{t:.4f}", f"{100 * t:.4f}"])

    return root


class FakeField:
    """A 2D field standing in for a slice, so rendering can be tested without FDS files."""

    kind = "slice"
    drawable = True

    def __init__(self, nx=8, ny=16, n_t=3, quantity="TEMPERATURE", unit="C"):
        self.label = f"{quantity} [{unit}] — x = 0 m"
        self.quantity = quantity
        self.unit = unit
        self.times = np.linspace(0.0, 2.0, n_t)
        self.axes = ("y", "z")
        self.coords = {"x": np.array([0.0]), "y": np.linspace(-2.0, 2.0, nx), "z": np.linspace(0.0, 8.0, ny)}
        self.shape = (nx, ny)
        # a blob that rises and grows, so frames differ both in where the heat is and
        # in how hot it gets -- which is what makes a per-step colour scale visible
        yy, zz = np.meshgrid(self.coords["y"], self.coords["z"], indexing="ij")
        self._frames = [20 + (150 + 180 * k) * np.exp(-(yy**2) - (zz - 1 - 2 * k) ** 2) for k in range(n_t)]

    def frame(self, timestep):
        return self._frames[timestep]

    def value_range(self):
        low = min(float(f.min()) for f in self._frames)
        high = max(float(f.max()) for f in self._frames)
        return low, high, False

    @property
    def cmap(self):
        return "inferno"

    def clear_cache(self):
        pass


@pytest.fixture
def fake_field():
    return FakeField()


@pytest.fixture
def fake_series():
    times = np.linspace(0.0, 4.0, 21)
    return [
        {
            "label": "DEVC  A — TEMPERATURE [C]",
            "name": "A",
            "times": times,
            "values": 20 + 10 * times,
            "quantity": "TEMPERATURE",
            "unit": "C",
            "source": "device",
            "device": None,
        },
        {
            "label": "DEVC  B — TEMPERATURE [C]",
            "name": "B",
            "times": times,
            "values": 20 + 4 * times**2,
            "quantity": "TEMPERATURE",
            "unit": "C",
            "source": "device",
            "device": None,
        },
    ]


@pytest.fixture(params=["missing", "empty", "header-only"])
def devc_without_data(request, tmp_path):
    """A simulation whose DEVC section is named in the .smv but has no usable data.

    FDS writes the .smv before the run finishes, so a case that was cut short -- or whose
    devices never fired -- leaves the CSV missing, empty or holding nothing but a header.
    fdsreader raises a different error for each.
    """
    root = tmp_path / request.param
    root.mkdir()
    (root / "c.smv").write_text(
        "CHID\n c\n\nCSVF\n devc\n c_devc.csv\n\nDEVICE\n TC % TEMPERATURE\n 1.0 0.0 1.0 0.0 0.0 1.0\n"
    )
    if request.param == "empty":
        (root / "c_devc.csv").write_text("")
    elif request.param == "header-only":
        (root / "c_devc.csv").write_text("s,C\nTime,TC\n")
    return root


@pytest.fixture
def simulation_with_nothing(tmp_path):
    """A simulation with no devices, no HRR file and no slices."""
    root = tmp_path / "nothing"
    root.mkdir()
    (root / "n.smv").write_text("CHID\n n\n")
    return root


@pytest.fixture
def devc_line_case(tmp_path):
    """A simulation with a DEVC *line*.

    FDS writes <chid>_line.csv for a line of devices, and fdsreader stores one scalar per
    point rather than a series -- a profile through space, not through time.
    """
    root = tmp_path / "line"
    root.mkdir()
    (root / "c.smv").write_text(
        "CHID\n c\n\n"
        "CSVF\n devc\n c_devc.csv\n\n"
        "DEVICE\n TC % TEMPERATURE\n 1.0 0.0 1.0 0.0 0.0 1.0\n\n"
        "DEVICE\n LINE % TEMPERATURE\n 1.0 0.0 0.5 0.0 0.0 1.0\n\n"
        "DEVICE\n LINE % TEMPERATURE\n 1.0 0.0 1.5 0.0 0.0 1.0\n"
    )
    (root / "c_devc.csv").write_text("s,C\nTime,TC\n0.0,20.0\n1.0,30.0\n2.0,45.0\n")
    (root / "c_line.csv").write_text("m,C\nHeight,LINE\n0.5,100.0\n1.5,200.0\n")
    return root


@pytest.fixture
def app(monkeypatch, fake_field, fake_series):
    """An interactive application over one field shown twice and two curves."""
    from explorer_helpers import FakeSim

    from fdsreader.explorer import tui

    monkeypatch.setattr(tui, "fields_of", lambda sim: [fake_field, fake_field])
    monkeypatch.setattr(tui, "build_series", lambda sim: fake_series)
    return tui.Interactive(FakeSim())


@pytest.fixture
def agg():
    """Draw on the Agg backend, so no display is needed, and close every figure afterwards."""
    plt = pytest.importorskip("matplotlib.pyplot")
    plt.switch_backend("Agg")
    yield plt
    plt.close("all")
