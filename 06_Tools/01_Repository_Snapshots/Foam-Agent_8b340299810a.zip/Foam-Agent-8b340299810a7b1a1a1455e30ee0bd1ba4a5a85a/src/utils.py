from logger import print
# utils.py
import re
import json
import subprocess
import os
import signal
from typing import Optional, Any, Type, TypedDict, List, Dict
from pydantic import BaseModel, Field
from langchain.chat_models import init_chat_model
from langchain_community.vectorstores import FAISS
from langchain_openai.embeddings import OpenAIEmbeddings
import tiktoken
from langchain_anthropic import ChatAnthropic
from pathlib import Path
import requests
import time
import random
import gzip
import zlib
from threading import Lock
from config import Config
from openfoam_target import database_path_for_config, require_target_corpus
try:
    from botocore.exceptions import ClientError
except ImportError:
    _AWS_CLIENT_ERRORS = ()
else:
    _AWS_CLIENT_ERRORS = (ClientError,)

try:
    from langchain_huggingface import HuggingFaceEmbeddings
except ImportError:
    HuggingFaceEmbeddings = None


FAISSCacheKey = tuple[str, str, str, str]
FAISS_DB_CACHE: Dict[FAISSCacheKey, Dict[str, Any]] = {}
_FAISS_DB_CACHE_LOCK = Lock()


def _faiss_cache_key(config: Config) -> FAISSCacheKey:
    """Return the cache identity for one embedding/index configuration."""
    provider = str(getattr(config, "embedding_provider", "openai") or "openai").casefold()
    model = str(getattr(config, "embedding_model", "") or "")
    model_path = str(getattr(config, "embedding_model_path", "") or "")
    return (str(database_path_for_config(config)), provider, model, model_path)

def get_embedding_model(config: Optional[Config] = None):
    """Return an embedding model based on the provided config.

    Note: historically this module accessed Config.* class attributes at import time.
    That works for defaults but breaks when callers pass a customized Config instance.
    """
    cfg = config or Config()

    provider = (cfg.embedding_provider or "openai").lower()
    model = cfg.embedding_model

    if provider == "openai":
        return OpenAIEmbeddings(model=model)
    if provider == "huggingface":
        if HuggingFaceEmbeddings is None:
            raise ImportError(
                "langchain-huggingface is not installed. Please install it to use HuggingFace embeddings."
            )
        model_path = getattr(cfg, "embedding_model_path", "")
        kwargs = {"model_kwargs": {"local_files_only": True}} if model_path else {}
        return HuggingFaceEmbeddings(model_name=model_path or model, **kwargs)
    if provider == "ollama":
        from langchain_ollama import OllamaEmbeddings
        return OllamaEmbeddings(model=model)

    raise ValueError(f"Unsupported embedding provider: {provider}")


def load_faiss_dbs(config: Optional[Config] = None):
    cfg = config or Config()
    require_target_corpus(cfg)
    embedding_model = get_embedding_model(cfg)

    base_dir = database_path_for_config(cfg) / "faiss"

    # Sanitize model name for directory usage
    model_dir_name = (cfg.embedding_model or "").replace("/", "_").replace(":", "_")
    db_path = base_dir / model_dir_name

    print(f"Loading FAISS indices from: {db_path} with model: {cfg.embedding_model}")

    dbs = {}
    indices = [
        "openfoam_allrun_scripts",
        "openfoam_tutorials_structure",
        "openfoam_tutorials_details",
        "openfoam_command_help",
    ]

    for index in indices:
        index_path = db_path / index
        if index_path.exists():
            try:
                dbs[index] = FAISS.load_local(
                    str(index_path), embedding_model, allow_dangerous_deserialization=True
                )
            except (OSError, RuntimeError, ValueError) as e:
                print(f"Failed to load index {index}: {e}")
        else:
            print(f"Warning: Index path does not exist: {index_path}")

    return dbs


# The embedding model can be large and may require a network/cache lookup.
# Defer it until a workflow actually performs retrieval; importing a service
# that does not use RAG (for example preflight validation) must stay local and
# deterministic.
def _ensure_faiss_dbs_loaded(config: Optional[Config] = None) -> Dict[str, Any]:
    """Load or reuse the index set matching ``config``."""
    cfg = config or Config()
    cache_key = _faiss_cache_key(cfg)
    # An empty mapping is also a cached result: repeatedly attempting to
    # load a missing index set is expensive and obscures the original
    # configuration error.
    with _FAISS_DB_CACHE_LOCK:
        if cache_key not in FAISS_DB_CACHE:
            FAISS_DB_CACHE[cache_key] = load_faiss_dbs(cfg)
        return FAISS_DB_CACHE[cache_key]

class FoamfilePydantic(BaseModel):
    file_name: str = Field(description="File basename only, such as epsilon or fvSolution; its directory belongs in folder_name")
    folder_name: str = Field(description="Case-relative directory, such as 0 or system; use an empty string for a root file")
    content: str = Field(description="Complete file content, using the syntax required by this file type")

class FoamPydantic(BaseModel):
    list_foamfile: List[FoamfilePydantic] = Field(description="List of OpenFOAM configuration files")

class _CodexResponsesWrapper:
    """Wrapper for an OpenAI Responses-compatible endpoint.

    This mimics the minimal interface LLMService expects from LangChain chat models:
    - invoke(messages) -> object with .content
    - get_num_tokens(text) -> int

    We support two wire endpoints:
    - OpenAI Platform: https://api.openai.com/v1/responses (API key / some OAuth tokens)
    - ChatGPT/Codex subscription backend: https://chatgpt.com/backend-api/codex/responses

    The ChatGPT backend requires a non-empty `instructions` field that matches the Codex harness
    expectations. We ship a default copy in `src/codex_instructions_default.txt`.
    """

    class _Resp:
        def __init__(self, content: str):
            if not content or not content.strip():
                raise ValueError("Empty response; expected JSON or final answer text.")
            self.content = content

    def __init__(
        self,
        token: str,
        model: str,
        temperature: float = 0.0,
        *,
        base_url: str = "https://api.openai.com/v1",
        account_id: Optional[str] = None,
        instructions: Optional[str] = None,
        stream: bool = False,
    ):
        self._token = token
        self._model = model
        self._temperature = temperature
        self._base_url = base_url.rstrip("/")
        self._account_id = account_id
        self._instructions = instructions
        self._stream = stream
        # Token counting (best-effort). Exact tokenization may differ by model.
        # We default to a modern tokenizer; adjust if you need model-specific counting.
        try:
            self._enc = tiktoken.get_encoding("o200k_base")
        except (KeyError, ValueError):
            self._enc = tiktoken.get_encoding("cl100k_base")

    def get_num_tokens(self, text: str) -> int:
        return len(self._enc.encode(text or ""))

    def with_structured_output(self, pydantic_obj: Type[BaseModel], *, method: str = "json_schema"):
        """Constrain the response at the endpoint, then validate it locally."""
        from openai.lib._pydantic import to_strict_json_schema

        if method != "json_schema":
            raise ValueError("The Responses wrapper supports native json_schema output.")
        response_format = {
            "type": "json_schema",
            "name": pydantic_obj.__name__,
            "strict": True,
            "schema": to_strict_json_schema(pydantic_obj),
        }

        parent = self

        class _StructuredWrapper:
            def get_num_tokens(self, text: str) -> int:
                return parent.get_num_tokens(text)

            def invoke(self, messages):
                resp = parent.invoke(messages, response_format=response_format)
                raw = getattr(resp, "content", "")
                if not raw.strip():
                    raise ValueError("Empty response; expected JSON")
                return pydantic_obj.model_validate_json(raw)

        return _StructuredWrapper()

    @staticmethod
    def _to_responses_input(messages):
        out = []
        for m in messages:
            role = m.get("role")
            content = m.get("content", "")
            # Responses API supports rich content; we use simple input_text.
            out.append({"role": role, "content": [{"type": "input_text", "text": content}]})
        return out

    @staticmethod
    def _extract_output_text(resp_json: dict) -> str:
        """Return the final answer, keeping progress messages out of artifacts."""
        if not isinstance(resp_json, dict):
            return ""
        if resp_json.get("error") or resp_json.get("status") in {"failed", "incomplete"}:
            raise RuntimeError(f"Responses failed: {resp_json.get('error') or resp_json.get('incomplete_details') or resp_json.get('status')}")
        messages = [item for item in resp_json.get("output", [])
                    if isinstance(item, dict) and item.get("type") in {None, "message"}]
        phased = any(item.get("phase") for item in messages)
        final = [item for item in messages if item.get("phase") == "final_answer"]
        messages = final or [item for item in messages if not item.get("phase")]
        if any(item.get("status") in {"in_progress", "incomplete"} for item in messages):
            raise RuntimeError("Responses returned an unfinished final answer.")
        if not phased and isinstance(resp_json.get("output_text"), str):
            return resp_json["output_text"]
        return "\n".join(
            content["text"] for item in messages for content in item.get("content", [])
            if isinstance(content, dict) and content.get("type") in {"output_text", "text"}
            and isinstance(content.get("text"), str)
        ).strip()

    def _build_payload(self, messages, *, response_format: Optional[dict] = None):
        payload = {
            "model": self._model,
            "input": self._to_responses_input(messages),
        }
        if response_format is not None:
            payload["text"] = {"format": response_format}

        # OpenAI Platform supports temperature.
        if "chatgpt.com" not in self._base_url:
            payload["temperature"] = self._temperature

        # ChatGPT/Codex subscription backend expects these extra keys.
        if "chatgpt.com" in self._base_url:
            payload.update(
                {
                    "instructions": self._instructions or "",
                    "tools": [],
                    "tool_choice": "auto",
                    "parallel_tool_calls": False,
                    "reasoning": {"summary": "auto"},
                    "store": False,
                    "stream": bool(self._stream),
                    "include": ["reasoning.encrypted_content"],
                }
            )
        return payload

    @staticmethod
    def _iter_sse_text(resp: requests.Response):
        """Yield decoded SSE 'data:' payloads as strings."""
        for raw in resp.iter_lines(decode_unicode=True):
            if not raw:
                continue
            if isinstance(raw, bytes):
                raw = raw.decode("utf-8", errors="ignore")
            line = str(raw).strip()
            if not line.startswith("data:"):
                continue
            data = line[len("data:") :].strip()
            if data == "[DONE]":
                break
            yield data

    def invoke(self, messages, *, response_format: Optional[dict] = None):
        url = f"{self._base_url}/responses"
        headers = {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
            "Accept": "application/json" if not self._stream else "text/event-stream",
            "User-Agent": "Foam-Agent",
        }
        if self._account_id:
            headers["ChatGPT-Account-Id"] = self._account_id

        payload = self._build_payload(messages, response_format=response_format)

        # ChatGPT Codex backend can take 60-180s on complex prompts when
        # reasoning.summary=auto is enabled — the model spends time on the
        # reasoning trace before emitting tokens. The previous hardcoded 60s
        # was too tight: prompts with non-trivial BC topology (e.g. a 2-inlet
        # elbow channel) deterministically exceeded it on gpt-5.5, raising
        # `HTTPSConnectionPool ... Read timed out. (read timeout=60)` and
        # failing the workflow. Allow operator override via env var.
        timeout = int(os.environ.get("FOAMAGENT_HTTP_TIMEOUT", "300"))
        r = requests.post(url, headers=headers, json=payload, timeout=timeout, stream=bool(self._stream))

        # If we get an error, surface the response body to aid debugging.
        if not r.ok:
            try:
                detail = r.text[:2000]
            except Exception:
                detail = ""
            raise requests.HTTPError(
                f"HTTP {r.status_code} for {url}. Body: {detail}", response=r
            )

        if not self._stream:
            data = r.json()
            return self._Resp(self._extract_output_text(data))

        # Preserve output-item identity: deltas can belong to commentary or the answer.
        items: dict[int, dict] = {}
        parts: dict[tuple[int, int], str] = {}
        completed = None
        for data in self._iter_sse_text(r):
            try:
                event = json.loads(data)
            except (ValueError, TypeError):
                continue
            if not isinstance(event, dict):
                continue
            kind = event.get("type")
            if kind in {"error", "response.failed", "response.incomplete"}:
                detail = event.get("error") or event.get("message") or event.get("response", {}).get("error") or kind
                raise RuntimeError(f"Responses stream failed: {detail}")
            if kind == "response.completed":
                completed = event.get("response")
            elif not kind and ("output" in event or "output_text" in event):
                completed = event
            index = event.get("output_index", 0)
            if kind in {"response.output_item.added", "response.output_item.done"}:
                item = event.get("item")
                if isinstance(item, dict):
                    items[index] = {**items.get(index, {}), **item}
            elif kind in {"response.output_text.delta", "response.output_text.done"}:
                key = (index, event.get("content_index", 0))
                if kind.endswith(".delta") and isinstance(event.get("delta"), str):
                    parts[key] = parts.get(key, "") + event["delta"]
                elif isinstance(event.get("text"), str):
                    parts[key] = event["text"]
        text = self._extract_output_text(completed) if isinstance(completed, dict) else ""
        if not text:
            # The subscription backend can finish with a metadata-only response.
            # Completed output items still carry the final answer in that stream.
            output = []
            for index in sorted(set(items) | {key[0] for key in parts}):
                item = dict(items.get(index) or {"type": "message"})
                if not item.get("content"):
                    item["content"] = [
                        {"type": "output_text", "text": parts[key]}
                        for key in sorted(parts) if key[0] == index
                    ]
                output.append(item)
            text = self._extract_output_text({"output": output})
        return self._Resp(text)



class LLMService:
    @staticmethod
    def _load_codex_oauth_from_auth_json(auth_json_path: Path) -> tuple[str, Optional[str]]:
        import json

        data = json.loads(auth_json_path.read_text(encoding="utf-8"))

        # Be permissive: different Codex versions may store different shapes.
        # Common patterns we try:
        #   {"access_token": "..."}
        #   {"token": "..."}
        #   {"tokens": {"access_token": "...", "account_id": "..."}}
        #   {"auth": {"access_token": "..."}}
        #   {"credentials": {"access_token": "..."}}
        candidates = []
        account_id = None

        def maybe_add(v):
            if isinstance(v, str) and v.strip():
                candidates.append(v.strip())

        if isinstance(data, dict):
            maybe_add(data.get("access_token"))
            maybe_add(data.get("token"))

            for k in ("auth", "credentials", "session"):
                v = data.get(k)
                if isinstance(v, dict):
                    maybe_add(v.get("access_token"))
                    maybe_add(v.get("token"))

            tokens = data.get("tokens")
            if isinstance(tokens, dict):
                maybe_add(tokens.get("access_token"))
                maybe_add(tokens.get("token"))
                if isinstance(tokens.get("account_id"), str) and tokens["account_id"].strip():
                    account_id = tokens["account_id"].strip()

        if not candidates:
            raise ValueError(
                f"Could not find an access token in {auth_json_path}. "
                "Expected keys like access_token/token or tokens.access_token."
            )

        # Prefer access_token-like strings first (we already appended in that order)
        return candidates[0], account_id

    @staticmethod
    def _load_codex_oauth_from_clawdbot_auth_profiles(auth_profiles_path: Path) -> tuple[str, Optional[str]]:
        """Load (access token, account id) from Clawdbot's OpenAI-Codex OAuth cache.

        Expected shape (v1):
          {"profiles": {"openai-codex:default": {"access": "...", "accountId": "...", ...}}}

        We also accept "openai-codex" and explicitly identified Codex profiles.
        """
        import json

        data = json.loads(auth_profiles_path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError(f"Unexpected JSON in {auth_profiles_path}")

        profiles = data.get("profiles")
        if not isinstance(profiles, dict):
            raise ValueError(f"Missing 'profiles' in {auth_profiles_path}")

        preferred_keys = ["openai-codex:default", "openai-codex"]
        for k in preferred_keys:
            v = profiles.get(k)
            if isinstance(v, dict):
                token = v.get("access")
                account_id = v.get("accountId")
                if isinstance(token, str) and token.strip():
                    return token.strip(), account_id if isinstance(account_id, str) else None

        # A different provider's access token cannot authenticate with Codex.
        for key, v in profiles.items():
            if isinstance(v, dict) and (
                key.startswith("openai-codex:") or v.get("provider") == "openai-codex"
            ):
                token = v.get("access")
                account_id = v.get("accountId")
                if isinstance(token, str) and token.strip():
                    return token.strip(), account_id if isinstance(account_id, str) else None

        raise ValueError(
            f"Could not find an 'access' token in {auth_profiles_path}. "
            "Expected profiles[*].access"
        )

    def _load_codex_oauth(self) -> tuple[str, Optional[str]]:
        """Load the Codex/ChatGPT OAuth token from a local auth cache.

        Supported locations (first match wins):
        1) $CODEX_HOME/auth.json (Codex CLI file-based cache)
        2) ~/.codex/auth.json (Codex CLI default)
        3) ~/.clawdbot/agents/main/agent/auth-profiles.json (Clawdbot OpenAI-Codex OAuth cache)

        Note: These files contain access/refresh tokens. Treat them like passwords.
        """
        candidates: list[Path] = []

        codex_home = os.getenv("CODEX_HOME")
        if codex_home:
            candidates.append(Path(codex_home) / "auth.json")

        candidates.append(Path.home() / ".codex" / "auth.json")

        # Clawdbot stores the OpenAI-Codex OAuth profile here.
        candidates.append(
            Path.home()
            / ".clawdbot"
            / "agents"
            / "main"
            / "agent"
            / "auth-profiles.json"
        )

        for p in candidates:
            if not p.exists():
                continue

            # Codex CLI cache
            if p.name == "auth.json":
                return self._load_codex_oauth_from_auth_json(p)

            # Clawdbot cache
            if p.name == "auth-profiles.json":
                return self._load_codex_oauth_from_clawdbot_auth_profiles(p)

        raise FileNotFoundError(
            "model_provider='openai-codex' requires a Codex/ChatGPT OAuth cache. "
            "Looked for: "
            + ", ".join(str(x) for x in candidates)
            + ". "
            "If you used the Codex CLI, run `codex login` and ensure file-based credential storage. "
            "If you used Clawdbot, make sure you completed OpenAI Codex OAuth in onboarding. "
            "To use an OpenAI Platform API key instead, set "
            "FOAMAGENT_MODEL_PROVIDER=openai along with OPENAI_API_KEY."
        )

    def _structured_output_method(self) -> str:
        """Return the configured mode, rejecting unsupported Codex native modes."""
        method = getattr(self._config, "structured_output_method", "auto")
        is_codex = self.model_provider.lower() in {"openai-codex", "codex", "chatgpt-oauth"}
        if is_codex and method not in {"auto", "json_schema", "json_prompt"}:
            raise ValueError(
                "The Codex subscription backend supports auto, json_schema or json_prompt "
                "for FOAMAGENT_STRUCTURED_OUTPUT_METHOD; "
                f"{method!r} is not supported by this subscription client."
            )
        return method

    def __init__(self, config: object):
        self.model_version = getattr(config, "model_version", "gpt-4o")
        self.temperature = getattr(config, "temperature", 0)
        self.model_provider = getattr(config, "model_provider", "openai")
        self._config = config
        # Reject unsupported modes before reading credentials or creating clients.
        self._structured_output_method()
        
        # Initialize statistics
        self.total_calls = 0
        self.total_prompt_tokens = 0
        self.total_completion_tokens = 0
        self.total_tokens = 0
        self.failed_calls = 0
        self.retry_count = 0
        
        # Initialize the LLM
        if self.model_provider.lower() == "bedrock":
            from langchain_aws import ChatBedrockConverse
            import tracking_aws

            bedrock_runtime = tracking_aws.new_default_client()
            self.llm = ChatBedrockConverse(
                client=bedrock_runtime, 
                model_id=self.model_version, 
                temperature=self.temperature, 
                max_tokens=8192
            )
        elif self.model_provider.lower() == "anthropic":
            self.llm = ChatAnthropic(
                model=self.model_version,
                temperature=self.temperature
            )
        elif self.model_provider.lower() == "openai":
            # Usage-based API access (requires OPENAI_API_KEY or equivalent OpenAI SDK config)
            self.llm = init_chat_model(
                self.model_version,
                model_provider=self.model_provider,
                temperature=self.temperature,
            )
        elif self.model_provider.lower() in {"openai-codex", "codex", "chatgpt-oauth"}:
            # Subscription-based access via "Sign in with ChatGPT" (Codex auth cache).
            # We use the OpenAI Responses API, which is the typical surface for Codex subscription access.
            token, account_id = self._load_codex_oauth()

            # ChatGPT/Codex subscription route: use the same endpoint as Codex CLI.
            # This avoids requiring Platform API scopes like api.responses.write.
            instructions_path = Path(__file__).resolve().parent / "codex_instructions_default.txt"
            try:
                instructions = instructions_path.read_text(encoding="utf-8")
            except OSError:
                instructions = "You are Codex, based on GPT-5. You are running as a coding agent in the Codex CLI on a user's computer."

            self.llm = _CodexResponsesWrapper(
                token=token,
                account_id=account_id,
                model=self.model_version,
                temperature=self.temperature,
                base_url="https://chatgpt.com/backend-api/codex",
                instructions=instructions,
                stream=True,
            )
        elif self.model_provider.lower() == "ollama":
            from langchain_ollama import ChatOllama

            try:
                requests.get("http://localhost:11434/api/version", timeout=2)
                # If request successful, service is running
            except requests.exceptions.RequestException:
                print("Ollama is not running, starting it...")
                subprocess.Popen(["ollama", "serve"], 
                                stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL)
                # Wait for service to start
                time.sleep(5)  # Give it 3 seconds to initialize

            self.llm = ChatOllama(
                model=self.model_version, 
                temperature=self.temperature,
                num_predict=-1,
                num_ctx=131072,
                base_url="http://localhost:11434"
            )
        elif self.model_provider.lower() == "deepseek":
            from langchain_openai import ChatOpenAI
            api_key = (os.getenv("DEEPSEEK_API_KEY") or "").strip()
            if not api_key:
                raise ValueError("model_provider='deepseek' requires DEEPSEEK_API_KEY.")
            reasoning = os.getenv("FOAMAGENT_REASONING_EFFORT", "max")
            if reasoning not in ("low", "medium", "high", "max"):
                reasoning = "max"
            # Note: temperature is ignored by DeepSeek in thinking mode.
            self.llm = ChatOpenAI(
                model=self.model_version,
                temperature=self.temperature,
                base_url="https://api.deepseek.com/v1",
                api_key=api_key,
                reasoning_effort=reasoning,
                extra_body={"thinking": {"type": "enabled"}},
            )
        else:
            raise ValueError(f"{self.model_provider} is not a supported model_provider")
    
    def _is_throttling_error(self, error: Exception) -> bool:
        """
        Check if an exception is a throttling-related error.
        
        Args:
            error: The exception to check
            
        Returns:
            True if it's a throttling error, False otherwise
        """
        # Check ClientError with specific error codes
        if isinstance(error, _AWS_CLIENT_ERRORS):
            error_code = error.response.get('Error', {}).get('Code', '')
            return error_code in ('Throttling', 'TooManyRequestsException', 'ThrottlingException')
        
        # Check for ThrottlingException and throttling-related error messages
        error_type = type(error).__name__
        error_str = str(error)
        
        throttling_indicators = (
            error_type == 'ThrottlingException',
            'ThrottlingException' in error_str,
            'Too many tokens' in error_str,
            'reached max retries' in error_str
        )
        
        return any(throttling_indicators)
    
    def _handle_throttling_retry(self, error: Exception, retry_count: int, max_retries: int) -> Optional[int]:
        """
        Handle throttling error by implementing exponential backoff retry logic.
        
        Args:
            error: The throttling exception
            retry_count: Current retry attempt number
            max_retries: Maximum number of retries allowed
            
        Returns:
            The updated retry count if retry should continue, None if max retries exceeded
        """
        retry_count += 1
        self.retry_count += 1
        
        if retry_count > max_retries:

            print(f"Maximum retries ({max_retries}) exceeded: {str(error)}")
            return None
        
        # Exponential backoff with jitter
        base_delay = 1.0
        max_delay = 60.0
        delay = min(max_delay, base_delay * (2 ** (retry_count - 1)))
        jitter = random.uniform(0, 0.1 * delay)
        sleep_time = delay + jitter
        
        print(f"ThrottlingException occurred: {str(error)}. Retrying in {sleep_time:.2f} seconds (attempt {retry_count}/{max_retries})")
        time.sleep(sleep_time)
        
        return retry_count

    @staticmethod
    def _is_retryable_transport_error(error: Exception) -> bool:
        """Recognise short-lived network failures from an LLM provider.

        Only connection, timeout, TLS and proxy transport errors are retried.
        HTTP response errors (for example authentication or invalid-request
        errors) are deliberately left to the caller because retrying them
        cannot make a malformed request valid.
        """
        return isinstance(
            error,
            (
                requests.exceptions.ConnectionError,
                requests.exceptions.Timeout,
                requests.exceptions.SSLError,
            ),
        )

    def _handle_transport_retry(
        self,
        error: Exception,
        retry_count: int,
        max_retries: int,
    ) -> Optional[int]:
        """Retry a transient LLM transport error with bounded backoff."""
        retry_count += 1
        self.retry_count += 1
        if retry_count > max_retries:
            print(f"Maximum transport retries ({max_retries}) exceeded: {error}")
            return None

        delay = min(8.0, 1.0 * (2 ** (retry_count - 1)))
        print(
            "Transient LLM transport error; retrying in "
            f"{delay:.1f} seconds (attempt {retry_count}/{max_retries}): {error}"
        )
        time.sleep(delay)
        return retry_count

    @staticmethod
    def _is_retryable_structured_response_error(error: Exception) -> bool:
        """Recognise transient empty/truncated structured-output responses.

        This deliberately does not retry arbitrary Pydantic validation errors:
        those usually indicate that the prompt or schema needs a real repair.
        It covers only the two failures emitted by the local structured-output
        wrapper before any JSON has been received.
        """
        message = str(error).casefold()
        return (
            "empty response; expected json" in message
            or "could not find a json object in response" in message
        )

    def _handle_structured_response_retry(
        self,
        error: Exception,
        retry_count: int,
        max_retries: int,
    ) -> Optional[int]:
        """Retry a transient empty structured response with bounded backoff."""
        retry_count += 1
        self.retry_count += 1
        if retry_count > max_retries:
            print(
                "Maximum structured-response retries "
                f"({max_retries}) exceeded: {error}"
            )
            return None

        delay = min(4.0, 0.5 * (2 ** (retry_count - 1)))
        print(
            "Structured LLM response was empty or truncated; retrying in "
            f"{delay:.1f} seconds (attempt {retry_count}/{max_retries})."
        )
        time.sleep(delay)
        return retry_count


    def invoke(self,
              user_prompt: str, 
              system_prompt: Optional[str] = None, 
              pydantic_obj: Optional[Type[BaseModel]] = None,
              max_retries: int = 10) -> Any:
        """
        Invoke the LLM with the given prompts and return the response.
        
        Args:
            user_prompt: The user's prompt
            system_prompt: Optional system prompt
            pydantic_obj: Optional Pydantic model for structured output
            max_retries: Maximum number of retries for throttling errors
            
        Returns:
            The LLM response with token usage statistics
        """
        self.total_calls += 1
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": user_prompt})
        
        # Calculate prompt tokens
        prompt_tokens = 0
        for message in messages:
            prompt_tokens += self.llm.get_num_tokens(message["content"])
        
        retry_count = 0
        transport_retry_count = 0
        structured_response_retry_count = 0
        while True:
            try:
                if pydantic_obj:
                    method = self._structured_output_method()
                    if method == "json_prompt" or (method == "auto" and self.model_provider.lower() == "deepseek"):
                        # Explicit compatibility mode, also preserving DeepSeek's
                        # existing thinking-mode fallback without response_format.
                        schema = pydantic_obj.model_json_schema()
                        json_instruction = (
                            "Return ONLY valid JSON (no markdown, no extra text) matching this schema:\n"
                            + str(schema)
                        )
                        json_messages = list(messages)
                        json_messages.append({"role": "user", "content": json_instruction})
                        raw_response = self.llm.invoke(json_messages)
                        raw_text = raw_response.content
                        # Strip markdown fences if present
                        t = raw_text.strip()
                        if t.startswith("```"):
                            t = re.sub(r"^```[a-zA-Z0-9_-]*\n?", "", t)
                            t = re.sub(r"\n?```\s*$", "", t).strip()
                        response = pydantic_obj.model_validate_json(t)
                    else:
                        structured_messages = list(messages)
                        if method == "json_mode":
                            structured_messages.append({
                                "role": "user",
                                "content": "Return JSON matching this schema: "
                                + json.dumps(pydantic_obj.model_json_schema()),
                            })
                        kwargs = {} if method == "auto" else {"method": method}
                        structured_llm = self.llm.with_structured_output(pydantic_obj, **kwargs)
                        response = structured_llm.invoke(structured_messages)
                else:
                    response = self.llm.invoke(messages)
                    response = response.content

                # Calculate completion tokens
                response_content = str(response)
                completion_tokens = self.llm.get_num_tokens(response_content)
                total_tokens = prompt_tokens + completion_tokens
                
                # Update statistics
                self.total_prompt_tokens += prompt_tokens
                self.total_completion_tokens += completion_tokens
                self.total_tokens += total_tokens
                
                return response
                
            except Exception as e:
                if self._is_throttling_error(e):
                    print(f"ThrottlingException occurred: {str(e)}.")
                    print(f"Retrying: {retry_count + 1}/{max_retries}")
                    retry_count = self._handle_throttling_retry(e, retry_count, max_retries)
                    if retry_count is None:
                        # Max retries exceeded
                        self.failed_calls += 1
                        raise RuntimeError(f"Maximum retries ({max_retries}) exceeded for throttling error: {str(e)}") from e
                    continue
                elif self._is_retryable_transport_error(e):
                    transport_retry_count = self._handle_transport_retry(e, transport_retry_count, 3)
                    if transport_retry_count is None:
                        self.failed_calls += 1
                        raise
                    continue
                elif pydantic_obj is not None and self._is_retryable_structured_response_error(e):
                    structured_response_retry_count = self._handle_structured_response_retry(e, structured_response_retry_count, 3)
                    if structured_response_retry_count is None:
                        self.failed_calls += 1
                        raise
                    continue
                else:
                    print(f"Non-throttling error occurred: {str(e)}.")

                    # Non-throttling error: log and raise
                    print(f"Error occurred in LLM service: {str(e)}")
                    if isinstance(e, _AWS_CLIENT_ERRORS):
                        print(e.response)
                    self.failed_calls += 1
                    raise e
    
    def get_statistics(self) -> dict:
        """
        Get the current statistics of the LLM service.
        
        Returns:
            Dictionary containing various statistics
        """
        return {
            "total_calls": self.total_calls,
            "failed_calls": self.failed_calls,
            "retry_count": self.retry_count,
            "total_prompt_tokens": self.total_prompt_tokens,
            "total_completion_tokens": self.total_completion_tokens,
            "total_tokens": self.total_tokens,
            "average_prompt_tokens": self.total_prompt_tokens / self.total_calls if self.total_calls > 0 else 0,
            "average_completion_tokens": self.total_completion_tokens / self.total_calls if self.total_calls > 0 else 0,
            "average_tokens": self.total_tokens / self.total_calls if self.total_calls > 0 else 0
        }
    
    def print_statistics(self) -> None:
        """
        Print the current statistics of the LLM service.
        """
        stats = self.get_statistics()
        print("\n<LLM Service Statistics>")
        print(f"Total calls: {stats['total_calls']}")
        print(f"Failed calls: {stats['failed_calls']}")
        print(f"Total retries: {stats['retry_count']}")
        print(f"Total prompt tokens: {stats['total_prompt_tokens']}")
        print(f"Total completion tokens: {stats['total_completion_tokens']}")
        print(f"Total tokens: {stats['total_tokens']}")
        print(f"Average prompt tokens per call: {stats['average_prompt_tokens']:.2f}")
        print(f"Average completion tokens per call: {stats['average_completion_tokens']:.2f}")
        print(f"Average tokens per call: {stats['average_tokens']:.2f}\n")
        print("</LLM Service Statistics>")

def load_agent_resources(config: Any) -> tuple[Any, Any]:
    """Build the target-specific LLM client and case statistics on demand."""
    require_target_corpus(config)
    stats_path = database_path_for_config(config) / "raw" / "openfoam_case_stats.json"
    with stats_path.open(encoding="utf-8") as handle:
        case_stats = json.load(handle)
    return LLMService(config), case_stats


class GraphState(TypedDict):
    user_requirement: str
    config: Config
    case_dir: str
    case_name: str
    subtasks: List[dict]
    mesh_review_history: List[dict]
    solver_review_history: List[dict]
    mesh_operations: List[dict]
    solver_operations: List[dict]
    pending_solver_operations: List[dict]
    solver_execution: Optional[dict]
    cross_stage_request: Optional[dict]
    solver_script_dirty: bool
    mesh_jobs: Optional[List[dict]]
    solver_jobs: Optional[List[dict]]
    solver_planned: bool
    replan_solver: bool
    pending_solver_subtasks: Optional[List[dict]]
    mesh_execution: Optional[dict]
    mesh_script_action: Optional[str]
    mesh_reference: Optional[dict]
    mesh_boundary_plan: Optional[List[dict]]
    final_reconstruction: Optional[dict]
    loop_count: int
    # Additional state fields that will be added during execution
    llm_service: Optional['LLMService']
    case_stats: Optional[dict]
    tutorial_reference: Optional[str]
    case_path_reference: Optional[str]
    dir_structure_reference: Optional[str]
    case_info: Optional[str]
    allrun_reference: Optional[str]
    dir_structure: Optional[dict]
    commands: Optional[List[str]]
    foamfiles: Optional[dict]
    error_logs: Optional[List[str]]
    history_text: Optional[List[str]]
    case_domain: Optional[str]
    case_category: Optional[str]
    case_solver: Optional[str]
    mesh_source: Optional[str]
    # Mesh-related state fields
    mesh_info: Optional[dict]
    mesh_commands: Optional[List[str]]
    custom_mesh_used: Optional[bool]
    mesh_type: Optional[str]
    mesh_subtasks: Optional[List[dict]]
    repairing_mesh: bool
    mesh_resume_state: Optional[dict]
    custom_mesh_path: Optional[str]
    # Review and rewrite related fields
    review_analysis: Optional[str]
    rewrite_plan: Optional[dict]
    input_writer_mode: Optional[str]
    repair_source: Optional[str]
    input_omissions: Optional[dict[str, str]]
    last_repair: Optional[dict]
    failed_run_inputs: Dict[str, List[Any]]
    case_input_source_dir: Optional[str]
    last_run_input_fingerprint: Optional[str]
    static_review_report: Optional[dict]
    static_review_retries: int
    static_review_complete: Dict[str, bool]  # Each initial stage review ends once.
    static_review_reports: Dict[str, dict]
    static_review_repair: Optional[dict]
    static_review_stage: Optional[str]
    similar_case_advice: Optional[dict]
    # Routing decision cache
    requires_hpc: Optional[bool]
    requires_visualization: Optional[bool]
    # HPC-related fields
    job_id: Optional[str]
    cluster_info: Optional[dict]
    slurm_script_path: Optional[str]
    termination_reason: Optional[str]
    # Existing cases share Meshing and the solver-planner/writer/runner/reviewer graph.
    workflow_mode: str
    case_origin: str
    user_requirement_explicit: bool
    case_import_path: Optional[str]
    case_import_subdir: Optional[str]
    case_import_manifest: Optional[Any]
    case_import_report_dir: Optional[str]
    case_context: Optional[dict]  # Import snapshot for initial checks and case selection.
    requires_meshing: bool
    requires_input_writer: bool
    workflow_status: str
    visualization_error: Optional[str]
    workflow_message: Optional[str]
    target_mismatch: bool

def tokenize(text: str) -> str:
    # Replace underscores with spaces
    text = text.replace('_', ' ')
    # Insert a space between a lowercase letter and an uppercase letter (global match)
    text = re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', text)
    return text.lower()

def save_file(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        f.write(content)
    print(f"Saved file at {path}")

def case_file_key(path: str | Path) -> str:
    """The same OpenFOAM file can have plain and gzip representations."""
    name = Path(path).as_posix()
    return name[:-3] if name.endswith(".gz") else name


def resolve_case_file(path: str | Path) -> Path:
    """Select the plain file first, as OpenFOAM does, then its gzip variant."""
    plain = Path(case_file_key(path))
    for candidate in (plain, Path(str(plain) + ".gz")):
        if candidate.is_symlink():
            raise ValueError(f"Case file variants must not be symbolic links: {candidate}")
        if candidate.is_file():
            return candidate
    return Path(path)


def read_case_text(path: str | Path, *, errors: str = "strict", limit: int | None = None) -> str:
    """Read native case text, including gzip inputs, with an optional byte limit."""
    actual = resolve_case_file(path)
    opener = gzip.open if actual.suffix == ".gz" else open
    with opener(actual, "rb") as stream:
        data = stream.read(limit) if limit is not None else stream.read()
    return data.decode("utf-8", errors=errors)


def reject_symbolic_links(path: str | Path) -> None:
    """Inspect lexical components before any resolution can hide a link."""
    path = Path(path).absolute()
    for component in (*reversed(path.parents), path):
        if component.is_symlink():
            raise ValueError(f"Case paths must not contain symbolic links: {component}")


def validate_case_text_target(path: str | Path) -> None:
    plain = Path(case_file_key(path))
    compressed = Path(str(plain) + ".gz")
    for candidate in (plain, compressed):
        reject_symbolic_links(candidate)
        if candidate.exists() and not candidate.is_file():
            raise IsADirectoryError(f"Case file variant is not a regular file: {candidate}")


def save_case_text(path: str | Path, content: str) -> Path:
    """Preserve an existing gzip input on logical-path edits and remove stale variants."""
    requested = Path(path)
    validate_case_text_target(requested)
    plain = Path(case_file_key(requested))
    compressed = Path(str(plain) + ".gz")
    actual = requested if requested.suffix == ".gz" else resolve_case_file(requested)
    actual.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if actual.suffix == ".gz" else open
    with opener(actual, "wt", encoding="utf-8") as stream:
        stream.write(content)
    alternate = plain if actual.suffix == ".gz" else compressed
    if alternate.is_file():
        alternate.unlink()
    print(f"Saved file at {actual}")
    return actual

def _time_directory_value(name: str) -> float | None:
    """Parse native decimal/hex scalar names without invalid file-name whitespace."""
    if not name.isascii() or "_" in name or name != name.strip():
        return None
    try:
        return (float.fromhex(name) if name.lstrip("+-").lower().startswith("0x")
                else float(name))
    except ValueError:
        return None
    except OverflowError:
        return float("-inf" if name.startswith("-") else "inf")


def _is_numeric_name(name: str) -> bool:
    """Return whether a case entry name represents an OpenFOAM time value."""
    return _time_directory_value(name) is not None


def is_initial_time_dir(name: str) -> bool:
    """Accept every numeric spelling of time zero, including 0.0 and 0e0."""
    return _time_directory_value(name) == 0


# Fixed native output/cache roots; ordinary names sharing a prefix remain inputs.
SOLVER_OUTPUT_DIRECTORIES = {"postProcessing", "VTK", "dynamicCode"}
_PROCESSOR_DIRECTORY_RE = re.compile(r"processor(?:[0-9]+|s[0-9]+(?:_[0-9]+-[0-9]+)?)")


def is_processor_dir(name: str) -> bool:
    """Recognize native uncollated/collated partitions and legacy processors."""
    return name == "processors" or _PROCESSOR_DIRECTORY_RE.fullmatch(name) is not None


def is_solver_output_dir(name: str) -> bool:
    """True for a directory a solver wrote, rather than one describing the case.

    scan_case_directory() feeds the reviewer and rewrite prompts, and everything it
    returns is embedded verbatim. Including written time directories made that prompt
    reach 22.5 MB (~5.6M tokens) on a case that had already run once -- a mesh's worth
    of field data per time step -- which no model can accept.
    """
    if name == "0.orig" or is_initial_time_dir(name):
        return False
    if is_processor_dir(name) or name in SOLVER_OUTPUT_DIRECTORIES:
        return True
    return _is_numeric_name(name)


def scan_case_directory(case_dir: str) -> Dict[str, List[str]]:
    """
    Scan an OpenFOAM case directory and return the directory structure.
    
    This function collects the files in each input directory (typically
    'system', 'constant', '0', etc.), including regional inputs for a case
    declaring constant/regionProperties. Bulk mesh files are read separately.
    Directories the solver wrote (time steps, native partitions, postProcessing) are skipped:
    they are output, not case definition, and embedding them overflows every prompt.
    
    Args:
        case_dir (str): Path to the OpenFOAM case directory
    
    Returns:
        Dict[str, List[str]]: Dictionary mapping folder names to lists of file names
            Example: {"system": ["controlDict", "fvSchemes"], "constant": ["transportProperties"]}
    
    Raises:
        FileNotFoundError: If case_dir does not exist
        PermissionError: If directory cannot be accessed
    
    Example:
        >>> structure = scan_case_directory("/path/to/case")
        >>> print(structure["system"])  # ["controlDict", "fvSchemes", "fvSolution"]
    """
    if not os.path.exists(case_dir):
        raise FileNotFoundError(f"Case directory does not exist: {case_dir}")
    
    dir_structure = {}
    base_depth = case_dir.rstrip(os.sep).count(os.sep)
    regional = any((Path(case_dir) / ("constant/regionProperties" + suffix)).is_file()
                   for suffix in ("", ".gz"))
    initial_directories = {
        path.name for path in Path(case_dir).iterdir()
        if path.is_dir() and is_initial_time_dir(path.name)
    }
    
    # Walk through the directory tree
    for root, dirs, files in os.walk(case_dir):
        current_depth = root.rstrip(os.sep).count(os.sep)
        dirs[:] = [d for d in dirs if not d.startswith('.')]
        # Do not descend into solver output; a native partition holds a full copy of the
        # mesh and every field, and reading it is pure cost.
        if current_depth == base_depth:
            dirs[:] = [d for d in dirs if not is_solver_output_dir(d)]
        elif current_depth == base_depth + 1:
            if regional and Path(root).name in {"system", "constant", *initial_directories}:
                dirs[:] = [d for d in dirs if d != "polyMesh"]
                if Path(root).name == "constant":
                    # Regional dictionaries have a mesh or corresponding input
                    # directory; do not embed unrelated geometry source trees.
                    dirs[:] = [d for d in dirs if (Path(root) / d / "polyMesh").is_dir()
                               or any((Path(case_dir) / parent / d).is_dir()
                                      for parent in ("system", *initial_directories))]
            else:
                dirs[:] = []
        else:
            dirs[:] = []
        if current_depth == base_depth + 1 or (regional and current_depth == base_depth + 2):
            folder_name = os.path.relpath(root, case_dir)
            if is_solver_output_dir(folder_name):
                continue
            # Filter out hidden files and only include regular files
            regular_files = [f for f in files if not f.startswith('.') and os.path.isfile(os.path.join(root, f))
                             and not (f.endswith('.gz') and f[:-3] in files)]
            if regular_files:
                dir_structure[folder_name] = regular_files
    
    return dir_structure


def read_case_foamfiles(case_dir: str, dir_structure: Optional[Dict[str, List[str]]] = None) -> 'FoamPydantic':
    """
    Read OpenFOAM files from a case directory and convert to FoamPydantic format.
    
    This function reads all OpenFOAM configuration files from the case directory
    (typically from 'system', 'constant', '0' folders) and creates a FoamPydantic
    object containing the file contents.
    
    Args:
        case_dir (str): Path to the OpenFOAM case directory
        dir_structure (Optional[Dict[str, List[str]]]): Pre-scanned directory structure.
            If None, will scan the directory automatically.
    
    Returns:
        FoamPydantic: Object containing list of FoamfilePydantic objects with file metadata
    
    Raises:
        FileNotFoundError: If case_dir does not exist
        UnicodeDecodeError: If files contain invalid encoding (will skip those files)
    
    Example:
        >>> foamfiles = read_case_foamfiles("/path/to/case")
        >>> print(len(foamfiles.list_foamfile))  # Number of files read
        >>> print(foamfiles.list_foamfile[0].file_name)  # "controlDict"
    """
    if not os.path.exists(case_dir):
        raise FileNotFoundError(f"Case directory does not exist: {case_dir}")
    
    # Scan directory structure if not provided
    if dir_structure is None:
        dir_structure = scan_case_directory(case_dir)
    
    foamfile_list = []
    
    # Read files from each folder
    for folder_name, file_names in dir_structure.items():
        seen_files = set()
        for file_name in file_names:
            file_path = os.path.join(case_dir, folder_name, file_name)
            
            try:
                actual = resolve_case_file(file_path)
                if actual in seen_files:
                    continue
                content = read_case_text(actual)
                seen_files.add(actual)
                
                foamfile_list.append(FoamfilePydantic(
                    file_name=actual.name,
                    folder_name=folder_name,
                    content=content
                ))
            except UnicodeDecodeError:
                print(f"Warning: Skipping file due to encoding error: {file_path}")
            except (OSError, EOFError, zlib.error) as e:
                print(f"Warning: Error reading file {file_path}: {e}")
    
    return FoamPydantic(list_foamfile=foamfile_list)

def native_job_info_setup(job_info_dir):
    """Enable native per-process termination records without changing case inputs."""
    import shlex
    return (
        'foamagent_control_dict=${FOAM_CONTROLDICT:-}\n'
        'if [ -z "$foamagent_control_dict" ]; then\n'
        '    foamagent_etc_files=$(foamEtcFile -all controlDict) || exit $?\n'
        '    mapfile -t foamagent_etc_files <<< "$foamagent_etc_files"\n'
        '    for ((foamagent_i=${#foamagent_etc_files[@]}-1; foamagent_i>=0; foamagent_i--)); do\n'
        '        foamagent_control_dict+=$\'\\n\'"$(cat -- "${foamagent_etc_files[foamagent_i]}")" || exit $?\n'
        '    done\n'
        'fi\n'
        'foamagent_info_switches="writeJobInfo 1;"\n'
        'if [ "${WM_PROJECT_VERSION:-}" = "10" ]; then\n'
        '    foamagent_info_switches+=" writeJobControl 1;"\n'
        'fi\n'
        'export FOAM_CONTROLDICT="$foamagent_control_dict"$\'\\n\'"InfoSwitches { $foamagent_info_switches }"\n'
        f'export FOAM_JOB_DIR={shlex.quote(str(job_info_dir))}\n'
    )


def run_command(
    script_path: str,
    out_file: str,
    err_file: str,
    working_dir: str,
    max_time_limit: int,
    *,
    openfoam_target: str = "",
    fail_fast: bool = False,
    job_info_dir: str | None = None,
) -> Dict[str, Any]:
    print(f"Executing script {script_path} in {working_dir}")
    script = Path(script_path).expanduser().resolve()
    if not script.is_file():
        raise FileNotFoundError(f"OpenFOAM script does not exist: {script}")
    openfoam_dir = os.getenv("WM_PROJECT_DIR")
    if not openfoam_dir:
        raise RuntimeError(
            "WM_PROJECT_DIR is not set. Please source OpenFOAM environment before running Foam-Agent "
            "(e.g., source env/common.sh and env/foamagent.sh)."
        )

    bashrc_path = Path(openfoam_dir).expanduser() / "etc" / "bashrc"
    if not bashrc_path.is_file():
        raise RuntimeError(f"OpenFOAM bashrc not found at: {bashrc_path}")

    # Never interpolate paths into shell source.  Script and bashrc paths can
    # legitimately contain spaces and, for imported cases, originate outside
    # Foam-Agent.  Passing them as positional parameters prevents shell
    # metacharacters from being interpreted as code.  Clear the positional
    # parameters before sourcing the ESI bashrc: it treats them as optional
    # configuration arguments rather than as opaque values.
    # Explicit native targets must execute against their matching installation.
    # Legacy callers pass the empty value and retain the historical command shape.
    shell_command = (
        'foamagent_bashrc="$1"; foamagent_script="$2"; foamagent_target="$3"; '
        'set --; source "$foamagent_bashrc" || exit $?; '
        'if [ "$foamagent_target" = "esi-v2006" ]; then '
        'case "${WM_PROJECT_VERSION:-}" in v2006|2006) ;; '
        '*) echo "Foam-Agent requires ESI/OpenCFD OpenFOAM v2006; '
        'active WM_PROJECT_VERSION=${WM_PROJECT_VERSION:-unset}" >&2; exit 64 ;; '
        'esac; '
        'elif [ "$foamagent_target" = "foundation-v10" ]; then '
        'if [ "${WM_PROJECT_VERSION:-}" != "10" ]; then '
        'echo "Foam-Agent requires Foundation OpenFOAM v10; '
        'active WM_PROJECT_VERSION=${WM_PROJECT_VERSION:-unset}" >&2; exit 64; '
        'fi; '
        'fi; '
        + (native_job_info_setup(job_info_dir) if job_info_dir is not None else '')
        + ('exec bash -e -o pipefail "$foamagent_script"' if fail_fast
           else 'exec bash "$foamagent_script"')
    )

    timed_out = False

    for output in (out_file, err_file):
        reject_symbolic_links(output)
        path = Path(output)
        if path.exists() and not path.is_file():
            raise ValueError(f"Execution output is not a regular file: {path}")

    with open(out_file, 'w') as out, open(err_file, 'w') as err:
        process = subprocess.Popen(
            [
                "bash",
                "-c",
                shell_command,
                "foamagent-runner",
                str(bashrc_path),
                str(script),
                openfoam_target,
            ],
            cwd=working_dir,
            # Stream child output directly to disk.  ``communicate()`` buffers
            # all solver output in memory and can OOM on a legitimate long CFD
            # run with verbose residual logs.
            stdout=out,
            stderr=err,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

        try:
            process.wait(timeout=max_time_limit)
        except subprocess.TimeoutExpired:
            timed_out = True
        finally:
            # The session can retain helpers after its leader has exited.
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
        if timed_out:
            timeout_message = (
                f"OpenFOAM execution exceeded the {max_time_limit} second timeout.\n"
            )
            out.write(timeout_message)
            err.write(timeout_message)
            print(f"Execution timed out: {script_path}")

    print(f"Executed script {script_path}")
    return {
        "returncode": process.returncode,
        "timed_out": timed_out,
    }


def run_owned_process(command, *, cwd, timeout, check=False, text=False):
    """Capture a local script and stop its owned helpers before returning."""
    import io
    import tempfile

    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        with subprocess.Popen(command, cwd=cwd, stdout=out, stderr=err,
                              text=text, start_new_session=True) as process:
            timed_out = False
            try:
                process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
            finally:
                # The group may still contain background helpers after its
                # leader exits, including PyVista's background Xvfb process.
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
            out.seek(0)
            err.seek(0)
            if timed_out:
                raise subprocess.TimeoutExpired(command, timeout, output=out.read(), stderr=err.read())
            if text:
                with io.TextIOWrapper(out, encoding=process.encoding, errors=process.errors) as stdout, \
                        io.TextIOWrapper(err, encoding=process.encoding, errors=process.errors) as stderr:
                    output, errors = stdout.read(), stderr.read()
            else:
                output, errors = out.read(), err.read()
    result = subprocess.CompletedProcess(command, process.returncode, output, errors)
    if check:
        result.check_returncode()
    return result


def run_openfoam_utility(
    command: List[str],
    *,
    working_dir: str,
    timeout: int,
    openfoam_target: str = "",
) -> subprocess.CompletedProcess[str]:
    """Execute one OpenFOAM utility with the requested native runtime.

    Legacy callers execute their command directly. Native target
    mesh preprocessing happens before an ``Allrun`` exists, so it sources and
    validates the selected installation itself.
    """
    if not command:
        raise ValueError("OpenFOAM utility command must not be empty.")

    run_kwargs = {
        "cwd": working_dir,
        "check": True,
        "text": True,
        "timeout": timeout,
    }
    if openfoam_target not in {"foundation-v10", "esi-v2006"}:
        return run_owned_process(command, **run_kwargs)

    openfoam_dir = os.getenv("WM_PROJECT_DIR")
    if not openfoam_dir:
        raise RuntimeError(
            f"Native {openfoam_target} mesh processing requires WM_PROJECT_DIR. "
            "Pass --openfoam_path for the selected installation or source its etc/bashrc."
        )
    bashrc_path = Path(openfoam_dir).expanduser() / "etc" / "bashrc"
    if not bashrc_path.is_file():
        raise RuntimeError(f"OpenFOAM bashrc not found at: {bashrc_path}")

    shell_command = (
        'foamagent_bashrc="$1"; target="$2"; shift 2; '
        'foamagent_command=("$@"); set --; '
        'source "$foamagent_bashrc" || exit $?; '
        'case "$target:${WM_PROJECT_VERSION:-}" in '
        'esi-v2006:v2006|esi-v2006:2006|foundation-v10:10) ;; '
        '*) echo "Foam-Agent runtime does not match target $target; '
        'active WM_PROJECT_VERSION=${WM_PROJECT_VERSION:-unset}" >&2; exit 64 ;; '
        'esac; '
        'exec "${foamagent_command[@]}"'
    )
    return run_owned_process(
        [
            "bash",
            "-c",
            shell_command,
            "foamagent-utility",
            str(bashrc_path),
            openfoam_target,
            *command,
        ],
        **run_kwargs,
    )


def check_foam_errors(directory: str) -> list:
    """Collect explicit OpenFOAM errors without imposing completion heuristics."""
    from services.execution_logs import current_execution_logs, scan_execution_log
    root = Path(directory)
    errors = []
    for path in current_execution_logs(root, {}):
        errors.extend({"file": path.relative_to(root).as_posix(), "error_content": error}
                      for error in scan_execution_log(path)["errors"][:32 - len(errors)])
        if len(errors) == 32:
            break
    return errors

def parse_context(text: str) -> str:
    """Remove a complete outer code fence, preserving the file's full contents."""
    lines = text.strip().splitlines(keepends=True)
    if (len(lines) >= 2
            and re.fullmatch(r"```[^`]*", lines[0].strip())
            and lines[-1].strip() == "```"):
        return "".join(lines[1:-1])
    return text

def retrieve_faiss(
    database_name: str,
    query: str,
    topk: int = 1,
    *,
    config: Optional[Config] = None,
) -> List[Dict[str, Any]]:
    """
    Retrieve a similar case from a FAISS database selected by ``config``.

    Omitting ``config`` retains the environment/default-backed behaviour used
    by legacy callers.  Supplying it is required when one process serves
    multiple configured workflows, because each embedding model needs its own
    compatible FAISS index and query vector.

    Return an empty list when the search finds no documents. Loading and search
    errors propagate to the caller.
    """

    dbs = _ensure_faiss_dbs_loaded(config)
    if database_name not in dbs:
        raise ValueError(f"Database '{database_name}' is not loaded.")

    # Tokenize the query
    query = tokenize(query)

    vectordb = dbs[database_name]
    try:
        docs_and_scores = vectordb.similarity_search_with_score(query, k=topk)
        docs = [d for d, _ in docs_and_scores]
        scores = [s for _, s in docs_and_scores]
    except (AttributeError, NotImplementedError):
        docs = vectordb.similarity_search(query, k=topk)
        scores = [None] * len(docs)

    formatted_results = []
    for doc, score in zip(docs, scores):
        metadata = doc.metadata or {}

        if database_name == "openfoam_allrun_scripts":
            formatted_results.append({
                "index": doc.page_content,
                "full_content": metadata.get("full_content", "unknown"),
                "case_name": metadata.get("case_name", "unknown"),
                "case_domain": metadata.get("case_domain", "unknown"),
                "case_category": metadata.get("case_category", "unknown"),
                "case_solver": metadata.get("case_solver", "unknown"),
                "dir_structure": metadata.get("dir_structure", "unknown"),
                "allrun_script": metadata.get("allrun_script", "N/A"),
                "score": score,
            })
        elif database_name == "openfoam_command_help":
            formatted_results.append({
                "index": doc.page_content,
                "full_content": metadata.get("full_content", "unknown"),
                "command": metadata.get("command", "unknown"),
                "help_text": metadata.get("help_text", "unknown"),
                "score": score,
            })
        elif database_name == "openfoam_tutorials_structure":
            formatted_results.append({
                "index": doc.page_content,
                "full_content": metadata.get("full_content", "unknown"),
                "case_name": metadata.get("case_name", "unknown"),
                "case_domain": metadata.get("case_domain", "unknown"),
                "case_category": metadata.get("case_category", "unknown"),
                "case_solver": metadata.get("case_solver", "unknown"),
                "dir_structure": metadata.get("dir_structure", "unknown"),
                "score": score,
            })
        elif database_name == "openfoam_tutorials_details":
            formatted_results.append({
                "index": doc.page_content,
                "full_content": metadata.get("full_content", "unknown"),
                "case_name": metadata.get("case_name", "unknown"),
                "case_domain": metadata.get("case_domain", "unknown"),
                "case_category": metadata.get("case_category", "unknown"),
                "case_solver": metadata.get("case_solver", "unknown"),
                "dir_structure": metadata.get("dir_structure", "unknown"),
                "tutorials": metadata.get("tutorials", "N/A"),
                "score": score,
            })
        else:
            raise ValueError(f"Unknown database name: {database_name}")

    return formatted_results
        

def parse_directory_structure(data: str) -> dict:
    """
    Parses the directory structure string and returns a dictionary where:
      - Keys: directory names
      - Values: count of files in that directory.
    """
    directory_file_counts = {}

    # Find all <dir>...</dir> blocks in the input string.
    dir_blocks = re.findall(r'<dir>(.*?)</dir>', data, re.DOTALL)

    for block in dir_blocks:
        # Match the producer's delimiter so dots remain part of directory names.
        dir_name_match = re.search(r'directory name:\s*(.*?)\. File names in this directory:', block)
        # Extract the list of file names within square brackets
        files_match = re.search(r'File names in this directory:\s*\[(.*?)\]', block)
        
        if dir_name_match and files_match:
            dir_name = dir_name_match.group(1).strip()
            files_str = files_match.group(1)
            # Split the file names by comma, removing any surrounding whitespace
            file_list = [filename.strip() for filename in files_str.split(',')]
            directory_file_counts[dir_name] = len(file_list)

    return directory_file_counts


def load_case_files(state: dict[str, Any]) -> dict[str, Any]:
    """Read the shared file state on import or mesh changes."""
    from services.case_inputs import read_case_inputs, canonical_input_protections
    from services.execution_logs import declared_startup_inputs

    case_dir = state.get("case_dir")
    if not case_dir:
        return {}
    directory = scan_case_directory(case_dir)
    input_directory = _case_input_directory(directory)
    scripts = [name for name in ("Allrun", "Allmesh", "generate_mesh.py")
               if (Path(case_dir) / name).is_file()]
    if scripts:
        input_directory[""] = scripts
    boundary = resolve_case_file(Path(case_dir) / "constant/polyMesh/boundary")
    if boundary.is_file():
        input_directory["constant/polyMesh"] = [boundary.name]
    constant = Path(case_dir) / "constant"
    if any((constant / ("regionProperties" + suffix)).is_file() for suffix in ("", ".gz")):
        for region in constant.iterdir():
            if region.is_dir() and not region.name.startswith('.'):
                boundary = resolve_case_file(region / "polyMesh/boundary")
                if boundary.is_file():
                    input_directory[boundary.parent.relative_to(Path(case_dir)).as_posix()] = [boundary.name]
    protected = canonical_input_protections(state.get('case_input_source_dir'), declared_startup_inputs([
        *state.get('mesh_operations', []), *state.get('solver_operations', []),
        *state.get('pending_solver_operations', []),
    ]))
    selected = [Path(folder) / name for folder, names in input_directory.items() for name in names]
    foamfiles, omitted = read_case_inputs(
        case_dir, protected_inputs=protected, selected_paths=[*selected, *protected])
    return {
        "dir_structure": directory,
        "foamfiles": foamfiles,
        "input_omissions": omitted,
    }


def _case_input_directory(directory: dict[str, list[str]]) -> dict[str, list[str]]:
    """Keep LLM context focused on dictionaries and the active field directory."""
    return {
        name: files
        for name, files in directory.items()
        if name.partition(os.sep)[0] in {"system", "constant"}
        or is_initial_time_dir(name.partition(os.sep)[0])
    }
