from logger import print
# config.py
import os
from dataclasses import dataclass
from pathlib import Path

from openfoam_target import normalise_openfoam_target


@dataclass
class Config:
    max_loop: int = 25
    searchdocs: int = 10 # max(10, searchdocs)
    run_times: int = 1   # current run number (for directory naming)
    database_path: str = Path(__file__).resolve().parent.parent / "database"
    run_directory: str = Path(__file__).resolve().parent.parent / "runs"
    case_dir: str = ""
    overwrite_case_dir: bool = False
    max_time_limit: int = 3600  # Max time limit after which the openfoam run will be terminated, in seconds
    # None budgets the graph for max_loop; an explicit limit remains unchanged.
    recursion_limit: int | None = None
    execution_mode: str = "careful"
    max_static_review_retries: int = 10  # Shared by both initial stage reviews
    # Input writer generation mode:
    # - "sequential_dependency": generate files sequentially; use already-generated files as context to enforce consistency.
    # - "parallel_no_context": generate files in parallel without cross-file context (faster, may need more reviewer iterations).
    input_writer_generation_mode: str | None = None
    # Optional: reuse previously generated files by copying from this directory.
    # If set, InputWriter will check <reuse_generated_dir>/<folder>/<file> first.
    # When present, it will copy into the current case_dir and skip LLM generation.
    reuse_generated_dir: str = ""
    # LLM backend:
    # - "openai": OpenAI Platform usage-based (API key)
    # - "openai-codex": ChatGPT/Codex subscription sign-in (Codex auth cache)
    # - "ollama": local models
    # - "bedrock": AWS Bedrock
    # - "anthropic": Anthropic Claude API (requires ANTHROPIC_API_KEY)
    model_provider: str = "openai-codex"  # [openai, openai-codex, ollama, bedrock, anthropic, deepseek]
    # model_version examples:
    # - OpenAI: "gpt-5-mini"
    # - OpenAI Codex subscription: "gpt-5.3-codex" (or whichever Codex model you have access to)
    # - Ollama: "qwen2.5:32b-instruct"
    # - Bedrock: application inference profile ARN
    # - Anthropic: claude-3-5-sonnet-latest
    model_version: str = "gpt-5.3-codex"
    temperature: float = 1
    structured_output_method: str = "auto"
    openfoam_fork: str = "foundation"  # Default to Foundation v10
    # An explicit target is additive.  Leaving it empty keeps the existing
    # Foundation/generic-ESI routing exactly as it was before v2006 support.
    openfoam_target: str = ""
    
    # Embedding Configuration
    embedding_provider: str = "huggingface"  # [openai, huggingface, ollama]
    embedding_model: str = "Qwen/Qwen3-Embedding-0.6B"  # e.g. "text-embedding-3-small", "text-embedding-3-large", "Qwen/Qwen3-Embedding-0.6B", "Qwen/Qwen3-Embedding-8B"
    # Loading location is independent of the model identity used by FAISS.
    embedding_model_path: str = ""

    @property
    def generation_mode(self) -> str:
        return self.input_writer_generation_mode or (
            "parallel_no_context" if self.execution_mode == "fast" else "sequential_dependency"
        )

    @property
    def static_review_enabled(self) -> bool:
        return self.execution_mode == "careful"

    @property
    def workflow_recursion_limit(self) -> int:
        # Mesh review uses the existing backend node. Initial solver review adds
        # one node; its longest repair route visits meshing planner, backend,
        # solver planner, writer and static review (five nodes per shared retry).
        static_steps = 5 * self.max_static_review_retries + 1 if self.static_review_enabled else 0
        return self.recursion_limit + static_steps

    def __post_init__(self) -> None:
        """Load config overrides from environment variables.

        Priority: env var (if set & non-empty) > default value.
        Always prints what value is used to make runs reproducible.
        """

        if self.recursion_limit is None:
            # A repair can traverse meshing_planner, meshing, solver_planner,
            # input_writer, runner and reviewer. Allow the initial pipeline,
            # optional visualization and the graph's final stop as well.
            self.recursion_limit = 6 * max(1, self.max_loop) + 8

        if self.execution_mode not in {"careful", "fast"}:
            raise ValueError("execution_mode must be careful or fast.")
        if self.input_writer_generation_mode not in {None, "sequential_dependency", "parallel_no_context"}:
            raise ValueError("input_writer_generation_mode must be sequential_dependency or parallel_no_context.")
        if not isinstance(self.max_static_review_retries, int) or self.max_static_review_retries < 0:
            raise ValueError("max_static_review_retries must be a non-negative integer.")

        def _env_nonempty(key: str) -> str | None:
            v = os.getenv(key)
            if v is None:
                return None
            v = v.strip()
            return v if v else None

        # LLM provider/model overrides
        provider_key = "FOAMAGENT_MODEL_PROVIDER"
        version_key = "FOAMAGENT_MODEL_VERSION"

        provider_env = _env_nonempty(provider_key)
        if provider_env is not None:
            allowed = {"openai", "openai-codex", "ollama", "bedrock", "anthropic", "deepseek"}
            if provider_env in allowed:
                self.model_provider = provider_env
                print(f"<config>model_provider={self.model_provider} (env:{provider_key})</config>")
            else:
                print(
                    f"<config>model_provider={self.model_provider} (default; invalid env:{provider_key}={provider_env!r})</config>"
                )
        else:
            print(f"<config>model_provider={self.model_provider} (default)</config>")

        version_env = _env_nonempty(version_key)
        if version_env is not None:
            self.model_version = version_env
            print(f"<config>model_version={self.model_version} (env:{version_key})</config>")
        else:
            print(f"<config>model_version={self.model_version} (default)</config>")

        self.structured_output_method = (
            _env_nonempty("FOAMAGENT_STRUCTURED_OUTPUT_METHOD") or self.structured_output_method
        )
        if self.structured_output_method not in {
            "auto", "json_schema", "function_calling", "json_mode", "json_prompt"
        }:
            raise ValueError(
                "Unsupported FOAMAGENT_STRUCTURED_OUTPUT_METHOD. Use auto, "
                "json_schema, function_calling, json_mode, or json_prompt."
            )

        # Embedding provider/model overrides
        emb_provider_key = "FOAMAGENT_EMBEDDING_PROVIDER"
        emb_model_key = "FOAMAGENT_EMBEDDING_MODEL"

        emb_provider_env = _env_nonempty(emb_provider_key)
        if emb_provider_env is not None:
            allowed_emb = {"openai", "huggingface", "ollama"}
            if emb_provider_env in allowed_emb:
                self.embedding_provider = emb_provider_env
                print(f"<config>embedding_provider={self.embedding_provider} (env:{emb_provider_key})</config>")
            else:
                print(
                    f"<config>embedding_provider={self.embedding_provider} (default; invalid env:{emb_provider_key}={emb_provider_env!r})</config>"
                )
        else:
            print(f"<config>embedding_provider={self.embedding_provider} (default)</config>")

        emb_model_env = _env_nonempty(emb_model_key)
        if emb_model_env is not None:
            self.embedding_model = emb_model_env
            print(f"<config>embedding_model={self.embedding_model} (env:{emb_model_key})</config>")
        else:
            print(f"<config>embedding_model={self.embedding_model} (default)</config>")

        self.embedding_model_path = (
            _env_nonempty("FOAMAGENT_EMBEDDING_MODEL_PATH") or self.embedding_model_path
        )
        if self.embedding_model_path:
            if self.embedding_provider.lower() != "huggingface":
                raise ValueError("FOAMAGENT_EMBEDDING_MODEL_PATH requires the huggingface embedding provider.")
            model_path = Path(self.embedding_model_path).expanduser().resolve()
            if not model_path.is_dir():
                raise ValueError(f"Local embedding model directory does not exist: {model_path}")
            self.embedding_model_path = str(model_path)

        # OpenFOAM Fork Override
        fork_key = "FOAMAGENT_OPENFOAM_FORK"
        fork_env = _env_nonempty(fork_key)
        if fork_env is not None:
            allowed_forks = {"foundation", "esi"}
            if fork_env.lower() in allowed_forks:
                self.openfoam_fork = fork_env.lower()
                print(f"<config>openfoam_fork={self.openfoam_fork} (env:{fork_key})</config>")
            else:
                self.openfoam_fork = "foundation"  # Safe fallback assignment
                print(f"<config>openfoam_fork={self.openfoam_fork} (default; invalid env:{fork_key}={fork_env!r})</config>")
        else:
            print(f"<config>openfoam_fork={self.openfoam_fork} (default)</config>")

        # Explicit version target.  This is intentionally separate from
        # FOAMAGENT_OPENFOAM_FORK so old ``esi`` configurations retain their
        # post-generation translation behaviour.
        target_key = "FOAMAGENT_OPENFOAM_TARGET"
        target_env = _env_nonempty(target_key)
        if target_env is not None:
            # Unlike the historical fork switch, this is an explicit native
            # platform contract.  Silently falling back to Foundation after a
            # spelling error could run a v2006 case against the wrong solver.
            self.openfoam_target = normalise_openfoam_target(target_env)
            print(
                f"<config>openfoam_target={self.openfoam_target} "
                f"(env:{target_key})</config>"
            )
        else:
            # Validate programmatic construction too, while preserving the
            # historical empty value as the legacy path.
            self.openfoam_target = normalise_openfoam_target(self.openfoam_target)
            label = self.openfoam_target or "legacy"
            print(f"<config>openfoam_target={label} (default)</config>")
