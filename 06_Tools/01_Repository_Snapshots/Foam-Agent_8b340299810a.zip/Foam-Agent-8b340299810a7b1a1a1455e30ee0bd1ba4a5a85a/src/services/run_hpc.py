from logger import print
from typing import Any, Optional, Tuple, Dict
import os
import json
import subprocess
import re
import time
import shutil
from models import RunOut
from utils import save_file, native_job_info_setup
from .solver_execution import check_solver_execution
from .execution_logs import declared_startup_inputs, check_execution_outputs
from .case_paths import safe_case_path
from .case_inputs import read_case_inputs
from . import get_llm_service


class HpcWorkflowStop(RuntimeError):
    """A stage cannot safely retry, or has exhausted the shared repair budget."""

    def __init__(self, reason: str, message: str, record=None):
        super().__init__(message)
        self.reason = reason
        self.record = record or {}

    def state_update(self):
        return {
            "workflow_status": "failed", "termination_reason": self.reason,
            "job_id": self.record.get("job_id"),
            "slurm_script_path": self.record.get("script"),
            "error_logs": [{"file": "hpc", "error_content": f"{self}\n{self.record}"}],
        }


def create_slurm_script(
    case_dir: str,
    cluster_info: dict,
    *,
    llm_service: Optional[Any] = None,
    openfoam_target: str = "",
    execution_script: str = "Allrun",
) -> str:
    """
    Create a SLURM script for OpenFOAM simulation using LLM.
    
    Args:
        case_dir: Directory containing the OpenFOAM case
        cluster_info: Dictionary containing cluster configuration
        
    Returns:
        str: Path to the created SLURM script
    """
    script_path = str(safe_case_path(case_dir, "", "submit_job.slurm"))
    system_prompt = (
        "You are an expert in HPC cluster job submission and SLURM scripting. "
        "Create a complete SLURM script for running OpenFOAM simulations. "
        "The script should include:"
        "1. Proper SLURM directives (#SBATCH) based on the cluster information provided"
        "2. Do not load openfoam"
        "3. Load libaraies for openfoam for run in parallel"
        f"4. Directory navigation and execution of the {execution_script} script"
        "5. Error handling and status reporting"
        "6. Any cluster-specific optimizations or requirements"
        "7. Use your understanding of the documentation of the cluster and figure out the syntax of their jobscript. "
    ) + (
        "8. The already-loaded OpenFOAM environment must be ESI/OpenCFD v2006. "
        "Do not substitute Foundation OpenFOAM commands or dictionaries."
        if openfoam_target == "esi-v2006"
        else ""
    ) + (
        "Return ONLY the complete SLURM script content. Do not include any explanations or markdown formatting."
        "Make sure the script is executable and follows best practices for the specified cluster."
    )
    
    user_prompt = (
        f"Create a SLURM script for OpenFOAM simulation with the following parameters:\n"
        f"Cluster: {cluster_info['cluster_name']}\n"
        f"Account: {cluster_info['account_number']}\n"
        f"Partition: {cluster_info['partition']}\n"
        f"Nodes: {cluster_info['nodes']}\n"
        f"Tasks per node: {cluster_info['ntasks_per_node']}\n"
        f"Time limit: {cluster_info['time_limit']} hours\n"
        f"Memory: {cluster_info['memory']} GB per node\n"
        f"Case directory: {case_dir}\n"
        f""
        f"Generate a complete SLURM script that will run the OpenFOAM simulation using the {execution_script} script."
    )
    
    llm_client = get_llm_service(llm_service)
    response = llm_client.invoke(user_prompt, system_prompt)
    
    # Clean up the response to extract just the script content
    script_content = response.strip()
    if script_content.startswith('```bash'):
        script_content = script_content[7:]
    elif script_content.startswith('```'):
        script_content = script_content[3:]
    if script_content.endswith('```'):
        script_content = script_content[:-3]
    script_content = script_content.strip()
    
    # Ensure the script starts with shebang
    if not script_content.startswith('#!/bin/bash'):
        script_content = '#!/bin/bash\n' + script_content
    
    script_content = _add_openfoam_runtime_guard(
        script_content,
        openfoam_target,
    )
    save_file(script_path, script_content)
    return script_path


def create_slurm_script_with_error_context(
    case_dir: str,
    cluster_info: dict,
    error_message: str = "",
    previous_script_content: str = "",
    *,
    llm_service: Optional[Any] = None,
    openfoam_target: str = "",
    execution_script: str = "Allrun",
) -> str:
    """
    Create a SLURM script for OpenFOAM simulation using LLM, with error context for retries.
    
    Args:
        case_dir: Directory containing the OpenFOAM case
        cluster_info: Dictionary containing cluster configuration
        error_message: Error message from previous submission attempt
        previous_script_content: Content of the previous failed SLURM script
        
    Returns:
        str: Path to the created SLURM script
    """
    script_path = str(safe_case_path(case_dir, "", "submit_job.slurm"))
    system_prompt = (
        "You are an expert in HPC cluster job submission and SLURM scripting. "
        "Create a complete SLURM script for running OpenFOAM simulations. "
        "The script should include:"
        "1. Proper SLURM directives (#SBATCH) based on the cluster information provided"
        "2. Do not load OpenFOAM"
        "3. Load libaraies for openfoam for run in parallel"
        f"4. Directory navigation and execution of the {execution_script} script"
        "5. Error handling and status reporting"
        "6. Any cluster-specific optimizations or requirements"
        "7. Use your understanding of the documentation of the cluster and figure out the syntax of their jobscript. "
    ) + (
        "8. The already-loaded OpenFOAM environment must be ESI/OpenCFD v2006. "
        "Do not substitute Foundation OpenFOAM commands or dictionaries."
        if openfoam_target == "esi-v2006"
        else ""
    ) + (
        "If a previous script and error message are provided, analyze the error and the script "
        "to identify what went wrong and fix it. Common issues to consider:"
        "- Invalid account numbers or partitions"
        "- Insufficient resources (memory, time, nodes)"
        "- Missing modules or environment variables"
        "- Incorrect file paths or permissions"
        "- Cluster-specific requirements or restrictions"
        "- Syntax errors in SLURM directives"
        "- Incorrect module names or versions"
        ""
        "Compare the previous script with the error message to identify the specific issue "
        "and create a corrected version."
        ""
        "Return ONLY the complete SLURM script content. Do not include any explanations or markdown formatting."
        "Make sure the script is executable and follows best practices for the specified cluster."
    )
    
    user_prompt = (
        f"Create a SLURM script for OpenFOAM simulation with the following parameters:\n"
        f"Cluster: {cluster_info['cluster_name']}\n"
        f"Account: {cluster_info['account_number']}\n"
        f"Partition: {cluster_info['partition']}\n"
        f"Nodes: {cluster_info['nodes']}\n"
        f"Tasks per node: {cluster_info['ntasks_per_node']}\n"
        f"Time limit: {cluster_info['time_limit']} hours\n"
        f"Memory: {cluster_info['memory']} GB per node\n"
        f"Case directory: {case_dir}\n"
    )
    
    if error_message and previous_script_content:
        user_prompt += f"\nPrevious submission failed with error: {error_message}\n"
        user_prompt += f"Previous SLURM script that failed:\n```bash\n{previous_script_content}\n```\n"
        user_prompt += "Please analyze this error and the previous script to identify the issue and create a corrected version."
    
    user_prompt += f"\nGenerate a complete SLURM script that will run the OpenFOAM simulation using the {execution_script} script. Return ONLY the complete SLURM script content. Do not include any explanations or markdown formatting."
    
    llm_client = get_llm_service(llm_service)
    response = llm_client.invoke(user_prompt, system_prompt)
    
    # Clean up the response to extract just the script content
    script_content = response.strip()
    if script_content.startswith('```bash'):
        script_content = script_content[7:]
    elif script_content.startswith('```'):
        script_content = script_content[3:]
    if script_content.endswith('```'):
        script_content = script_content[:-3]
    script_content = script_content.strip()
    
    # Ensure the script starts with shebang
    if not script_content.startswith('#!/bin/bash'):
        script_content = '#!/bin/bash\n' + script_content
    
    script_content = _add_openfoam_runtime_guard(
        script_content,
        openfoam_target,
    )
    save_file(script_path, script_content)
    return script_path


def submit_slurm_job(script_path: str, *, timeout: float = 60) -> Tuple[Optional[str], bool, str]:
    environment = dict(os.environ)
    environment.pop("SBATCH_WAIT", None)
    try:
        # The script's runtime guard checks $WM_PROJECT_VERSION before any module-load
        # step (the generated script is told not to source OpenFOAM itself), so it
        # relies on the submitting shell's environment reaching the job. sbatch's
        # inherited-environment default isn't guaranteed on every site (some default
        # to --export=NONE); pass --export=ALL explicitly so Foam-Agent's own already-
        # sourced OpenFOAM environment (required just to run this process) is what the
        # guard sees, instead of failing closed on every explicit-target HPC run.
        result = subprocess.run(
            ["sbatch", "--export=ALL", script_path],
            capture_output=True,
            text=True,
            check=False,
            env=environment,
            timeout=min(timeout, 60),
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError) as error:
        result = error
    def decoded(value):
        return value.decode(errors="replace") if isinstance(value, bytes) else value or ""
    output = "\n".join(decoded(getattr(result, name, "")) for name in ("stdout", "stderr"))
    ids = set(re.findall(r'^Submitted batch job ([0-9]+)(?: on cluster ([^\s;]+))?[ \t]*$', output, re.M))
    parsable = re.fullmatch(r'\s*([0-9]+)(?:;([^\s;]+))?\s*', decoded(getattr(result, "stdout", "")))
    if parsable:
        ids.add((parsable[1], parsable[2] or ""))
    if len(ids) == 1:
        number, cluster = ids.pop()
        return number + (";" + cluster if cluster else ""), True, ""
    rejected = re.search(
        r'\b(?:invalid partition(?: specified| name)|invalid account|unrecognized option|'
        r'unrecognized argument|invalid (?:option|argument)|invalid --[\w-]+ specification)\b', output, re.I)
    if not isinstance(result, (subprocess.TimeoutExpired, OSError)) and getattr(result, 'returncode', 0) and rejected:
        return None, False, f"Failed to submit job: {output.strip()}"
    raise HpcWorkflowStop("hpc_submission_unconfirmed",
                          f"Submission could not be confirmed: {output.strip() or str(result)}")


def check_job_status(job_id: str, *, timeout: Optional[float] = None) -> Tuple[Optional[str], bool, str]:
    try:
        number, cluster_args = _slurm_job_identity(job_id)
        result = subprocess.run(["squeue", *cluster_args, "-j", number, "--noheader", "-o", "%T"], capture_output=True, text=True, check=True, timeout=timeout)
        status = result.stdout.strip()
        if status:
            return status, True, ""
        return "COMPLETED", True, ""
    except subprocess.CalledProcessError as e:
        return None, False, f"Failed to check job status: {e.stderr}"
    except Exception as e:
        return None, False, f"Unexpected error: {str(e)}"


def _slurm_job_identity(job_id):
    """Retain sbatch's cluster identity through monitoring and cancellation."""
    number, _, cluster = job_id.partition(";")
    return number, ["--clusters", cluster] if cluster else []


def run_simulation_hpc(script_path: str, *, timeout: float = 60) -> RunOut:
    job_id, ok, err = submit_slurm_job(script_path, timeout=timeout)
    status = "submitted" if ok else f"failed: {err}"
    return RunOut(job_id=job_id, status=status)


def extract_cluster_info_from_requirement(
    user_requirement: str,
    case_dir: str,
    *,
    llm_service: Optional[Any] = None,
) -> Dict:
    """
    Extract cluster information from user requirement using LLM.
    
    Args:
        user_requirement: User requirement text
        case_dir: Directory containing the OpenFOAM case
        
    Returns:
        dict: Dictionary containing cluster_name, account_number, and other cluster details
    """
    inputs, omitted = read_case_inputs(case_dir, selected_paths=['system/decomposeParDict'])
    decompose_par_dict_content = next((file.content for file in inputs.list_foamfile), "")
    
    system_prompt = (
        "You are an expert in HPC cluster analysis. "
        "Analyze the user requirement to extract cluster information. "
        "Look for keywords like: cluster name, account number, partition, queue, "
        "specific cluster names (e.g., Stampede2, Frontera, Summit, etc.), "
        "account numbers, project codes, or any mention of specific HPC systems. "
        ""
        "IMPORTANT: If a decomposeParDict file is provided, analyze it to determine "
        "the appropriate number of tasks per node (ntasks_per_node) based on the "
        "decomposition settings. The number of tasks should match the total number "
        "of subdomains or processes specified in the decomposeParDict."
        ""
        "Return a JSON object with the following structure: "
        "{"
        "  'cluster_name': 'name of the cluster or HPC system', "
        "  'account_number': 'account number or project code', "
        "  'partition': 'partition name (e.g., normal, debug, gpu)', "
        "  'nodes': 'number of nodes (default: 1)', "
        "  'ntasks_per_node': 'number of tasks per node (determine from decomposeParDict if available)', "
        "  'time_limit': 'time limit in hours (default: 24)', "
        "  'memory': 'memory per node in GB (default: 64)'"
        "}"
        "If any information is not specified, use reasonable defaults based on your expertise. "
        "Only return valid JSON. Don't include any other text."
    )
    
    user_prompt = (
        f"User requirement: {user_requirement}\n\n"
    )
    
    if decompose_par_dict_content:
        user_prompt += (
            f"decomposeParDict content:\n{decompose_par_dict_content}\n\n"
            "Analyze the decomposeParDict to determine the appropriate number of tasks per node "
            "based on the decomposition settings. "
        )

    if omitted:
        user_prompt += f"\n<omitted_files>{json.dumps(omitted)}</omitted_files>\n"
    
    user_prompt += "Extract cluster information and return as JSON object."
    
    llm_client = get_llm_service(llm_service)
    response = llm_client.invoke(user_prompt, system_prompt)
    
    response = response.strip()
    if response.startswith('```json'):
        response = response[7:]
    if response.endswith('```'):
        response = response[:-3]
    cluster_info = json.loads(response.strip())
    if not isinstance(cluster_info, dict):
        raise ValueError("Cluster configuration must be a JSON object")

    required = ('cluster_name', 'account_number', 'partition', 'nodes',
                'ntasks_per_node', 'time_limit', 'memory')
    missing = [key for key in required if key not in cluster_info or cluster_info[key] is None]
    if missing:
        raise ValueError("Cluster configuration is missing required fields: " + ", ".join(missing))
    return cluster_info


def check_logs_for_errors(case_dir: str, *, fields_before: dict[str, tuple[int, ...]],
                          logs_before: dict[str, tuple[int, ...]], protected_inputs=(),
                          openfoam_target: str = "", timeout: int = 3600, job_info_dir=None):
    """Return parsed OpenFOAM error logs for a case directory."""
    return check_solver_execution(
        case_dir, fields_before=fields_before, logs_before=logs_before,
        protected_inputs=protected_inputs, openfoam_target=openfoam_target, timeout=timeout,
        job_info_dir=job_info_dir)


def wait_for_job(job_id: str, max_wait_time: int = 3600, wait_interval: int = 30) -> Tuple[str, bool, str]:
    """Poll job status until finished or timeout. Returns (status, ok, err)."""
    deadline = time.monotonic() + max_wait_time
    last_status = "PENDING"
    while (remaining := deadline - time.monotonic()) > 0:
        status, ok, err = check_job_status(job_id, timeout=remaining)
        if not ok:
            if time.monotonic() >= deadline:
                return "TIMEOUT", False, f"Monitoring exceeded {max_wait_time}s: {err}"
            return status or "UNKNOWN", False, err
        last_status = status
        if status in {"COMPLETED", "FAILED", "CANCELLED", "TIMEOUT", "OUT_OF_MEMORY", "NODE_FAIL", "PREEMPTED", "BOOT_FAIL", "DEADLINE", "REVOKED"}:
            return status, True, ""
        remaining = deadline - time.monotonic()
        if remaining > 0:
            time.sleep(min(wait_interval, remaining))
    return "TIMEOUT", False, f"Monitoring exceeded {max_wait_time}s; last state: {last_status}"


# Native sbatch option arity is needed only to distinguish --wait/-W from an
# option's value. Scheduler option/resource validation remains sbatch's job.
# https://github.com/SchedMD/slurm/blob/master/src/common/slurm_opt.c
_SBATCH_REQUIRED_ARGUMENTS = set("""
    account acctg-freq array batch bbf autocomplete begin bb cluster-constraint
    chdir clusters cluster comment constraint container-id runtime context
    core-spec cores-per-socket cpu-freq cpus-per-gpu cpus-per-task deadline
    delay-boot dependency distribution error exclude export export-file extra
    extra-node-info gid gpu-bind tres-bind gpu-freq gpus gpus-per-node
    gpus-per-socket gpus-per-task tres-per-task gres gres-flags hint input job-name
    kill-on-invalid-dep kv layout licenses mail-type mail-user max-pids mcs-label
    mem mem-bind mem-per-cpu mem-per-gpu mem-update mincpus network nodefile
    nodelist nodes ntasks ntasks-per-core ntasks-per-node ntasks-per-socket
    ntasks-per-tres ntasks-per-gpu open-mode output partition prefer priority
    profile qos relay-io reservation resources segment signal sockets-per-node
    switches tasks-per-node thread-spec threads-per-core time time-min tmp uid
    user wait-all-nodes wckey wrap
""".split())
_SBATCH_FLAG_OPTIONS = set("""
    consolidate-segments contiguous external get-user-env help hold ignore-pbs
    no-requeue overcommit oversubscribe parsable quiet reboot spread-job
    spread-segments stepmgr test-only use-min-nodes usage verbose version wait
    exclusive oom-kill-step nice no-kill propagate requeue resv-ports
""".split())


def _slurm_directive_arguments(text):
    """Follow sbatch get_argument quoting, escapes and comments, not shell syntax."""
    argument, quote, escaped = None, None, False
    for character in text:
        if argument is None:
            if character.isspace():
                continue
            argument = []
        if escaped:
            argument.append(character)
            escaped = False
        elif character == '\\':
            escaped = True
        elif quote:
            if character == quote:
                quote = None
            else:
                argument.append(character)
        elif character in "\"'":
            quote = character
        elif character == '#':
            break
        elif character.isspace():
            if not argument:
                return
            yield ''.join(argument)
            argument = None
        else:
            argument.append(character)
    if quote:
        raise ValueError('Unmatched quote in Slurm directive')
    if argument:
        yield ''.join(argument)


def _reject_submission_wait(script_content: str) -> None:
    """Inspect native leading directives without interpreting the job program."""
    arguments = []
    for line in script_content.splitlines():
        directive = re.match(r'^#(?:SBATCH|SLURM)(.*)$', line)
        if directive:
            arguments.extend(_slurm_directive_arguments(directive[1]))
        elif line.strip() and not line.lstrip().startswith('#'):
            break
    tokens = iter(arguments)
    for token in tokens:
        if token == '--':
            break
        if token.startswith('--'):
            name, equals, _ = token[2:].partition('=')
            if name == 'wait':
                raise ValueError('Slurm --wait/-W directives are not allowed; submission must return a job ID promptly')
            if not equals:
                # getopt_long accepts an unambiguous abbreviation too.
                names = _SBATCH_REQUIRED_ARGUMENTS | _SBATCH_FLAG_OPTIONS
                matches = {name} if name in names else {option for option in names if option.startswith(name)}
                if len(matches) == 1 and matches <= _SBATCH_REQUIRED_ARGUMENTS:
                    next(tokens, None)
        elif token.startswith('-'):
            for index, option in enumerate(token[1:], start=1):
                if option == 'W':
                    raise ValueError('Slurm --wait/-W directives are not allowed; submission must return a job ID promptly')
                if option in 'ABCDFGJLMNSabcdeimnopqtwx':
                    if index == len(token) - 1:
                        next(tokens, None)
                    break
                if option == 'k':  # Optional short argument consumes only attached text.
                    break


def _add_openfoam_runtime_guard(
    script_content: str,
    openfoam_target: str,
) -> str:
    """Make an explicit native-target job fail on a mismatched runtime."""
    _reject_submission_wait(script_content)
    if openfoam_target not in {"foundation-v10", "esi-v2006"}:
        return script_content
    expected = "v2006|2006" if openfoam_target == "esi-v2006" else "10"
    guard = (
        f'case "{openfoam_target}:${{WM_PROJECT_VERSION:-}}" in\n'
        + (
            "    esi-v2006:v2006|esi-v2006:2006) ;;\n"
            if openfoam_target == "esi-v2006"
            else "    foundation-v10:10) ;;\n"
        )
        + f'    *) echo "Foam-Agent requires {openfoam_target} ({expected}) on this cluster." >&2; exit 64 ;;\n'
        + "esac\n"
    )
    lines = script_content.splitlines()
    # Keep the leading comments and #SBATCH directives before executable code.
    insert_at = 0
    while insert_at < len(lines):
        line = lines[insert_at].strip()
        if line and not line.startswith("#"):
            break
        insert_at += 1
    return "\n".join([*lines[:insert_at], guard.rstrip("\n"), *lines[insert_at:]]) + "\n"


def hpc_execution_outputs(stage):
    script = "Allmesh" if stage == "mesh" else "Allrun"
    return [f"{script}.out", f"{script}.err", "submit_job.slurm"]


def run_stage_hpc(state, script, stage, timeout):
    """Submit one stage attempt; queue disappearance alone is not completion."""
    from pathlib import Path
    import tempfile
    import shlex
    operations = state.get(stage + "_operations") or []
    if stage == "mesh":
        operations = [*operations, *(state.get("solver_operations") or []),
                      *(state.get("pending_solver_operations") or [])]
    output_paths = hpc_execution_outputs(stage)
    from .case_inputs import canonical_input_protections
    conflicts = check_execution_outputs(output_paths, canonical_input_protections(
        state.get('case_input_source_dir'), declared_startup_inputs(operations)))
    if conflicts:
        raise ValueError(str(conflicts))
    deadline = time.monotonic() + timeout
    # Validate lexical destinations before resolution or metadata creation.
    destinations = [safe_case_path(state["case_dir"], "", name) for name in output_paths]
    case = destinations[0].parent
    root = safe_case_path(case, ".foamagent", stage + "-jobs")
    root.mkdir(parents=True, exist_ok=True)
    attempt = Path(tempfile.mkdtemp(prefix="attempt-", dir=root))
    marker, out, err = (attempt / name for name in ("exit-code", "stdout", "stderr"))
    job_info_dir = attempt / 'native-jobs' if stage == 'solver' else None
    if job_info_dir is not None:
        job_info_dir.mkdir()
    wrapper = attempt / "run-stage.sh"
    q = lambda p: shlex.quote(str(p))
    wrapper.write_text("#!/bin/bash\n" +
        f"cd {q(case)} || exit 1\n" +
        (native_job_info_setup(job_info_dir) if job_info_dir is not None else '') +
        f"bash -e -o pipefail {q(Path(script).resolve())} > {q(out)} 2> {q(err)}\n" +
        "rc=$?\n" + f"printf '%s\\n' \"$rc\" > {q(marker)}.tmp\n" +
        f"mv {q(marker)}.tmp {q(marker)}\nexit \"$rc\"\n")
    wrapper.chmod(0o700)
    client = get_llm_service(state.get('llm_service'), state['config'])
    try:
        cluster = extract_cluster_info_from_requirement(state["user_requirement"], str(case), llm_service=client)
    except ValueError as error:
        raise HpcWorkflowStop("hpc_configuration_failed", f"Cannot determine cluster configuration: {error}") from error
    state["cluster_info"] = cluster
    from openfoam_target import runtime_openfoam_target
    previous_script, submission_error = "", ""
    record = {"job_id": None, "output": str(out), "error": str(err)}
    submission_number = 0
    while True:
        if submission_error and state.get("loop_count", 0) >= state["config"].max_loop:
            raise HpcWorkflowStop("max_review_loop_reached", "Slurm submission exhausted the shared repair budget", record)
        kwargs = dict(llm_service=client,
                      openfoam_target=runtime_openfoam_target(state["config"]), execution_script=str(wrapper))
        if submission_error:
            batch = create_slurm_script_with_error_context(str(case), cluster, submission_error, previous_script, **kwargs)
        else:
            batch = create_slurm_script(str(case), cluster, **kwargs)
        previous_script = Path(batch).read_text()
        submission_number += 1
        batch_copy = attempt / f"submit-{submission_number}.slurm"
        batch_copy.write_text(previous_script)
        record = {"job_id": None, "script": str(batch_copy), "output": str(out), "error": str(err)}
        if job_info_dir is not None:
            record['job_info_dir'] = str(job_info_dir)
        state.setdefault(stage + "_jobs", []).append(record)
        try:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise HpcWorkflowStop('hpc_stage_timeout', 'Stage budget expired before Slurm submission', record)
            submitted = run_simulation_hpc(str(batch_copy), timeout=min(remaining, 60))
        except HpcWorkflowStop as stop:
            record.update(status="submission_unknown" if stop.reason == 'hpc_submission_unconfirmed' else 'not_submitted',
                          returncode=1, diagnostic=str(stop))
            stop.record = record
            raise
        record.update(job_id=submitted.job_id, status=submitted.status)
        if submitted.status == "submitted" and submitted.job_id:
            break
        record["returncode"] = 1
        if not submitted.status.startswith("failed:") or submitted.job_id:
            raise HpcWorkflowStop("hpc_submission_unconfirmed", "Submission result is not a confirmed rejection", record)
        submission_error = submitted.status
        state["loop_count"] = state.get("loop_count", 0) + 1

    status, ok, error = wait_for_job(submitted.job_id, max_wait_time=max(0, deadline - time.monotonic()))
    record["status"] = status
    if not ok:
        try:
            number, cluster_args = _slurm_job_identity(submitted.job_id)
            cancelled = subprocess.run(["scancel", *cluster_args, number], check=False, capture_output=True, text=True, timeout=60)
            record["cancellation"] = {"returncode": cancelled.returncode, "stderr": cancelled.stderr}
        except Exception as exc:
            record["cancellation"] = {"error": str(exc)}
        final_status, confirmed, confirmation_error = wait_for_job(submitted.job_id, max_wait_time=60, wait_interval=5)
        record.update(cancellation_status=final_status, cancellation_diagnostic=confirmation_error)
        if not confirmed:
            record.update(returncode=1, diagnostic=error)
            raise HpcWorkflowStop("hpc_job_state_unconfirmed", "Could not confirm that the Slurm job stopped; no further work will run", record)
    try:
        code = int(marker.read_text().strip())
        executed = ok
    except (OSError, ValueError):
        code = 1
        executed = False
        error = error or "No exit result for this stage attempt"
    record.update(returncode=code if ok and status == "COMPLETED" else 1,
                  timed_out=status == "TIMEOUT", diagnostic=error, executed=executed)
    # Keep conventional stage outputs for the existing error collector.
    # Native operations may have replaced a destination since preflight. Check
    # both streams before copying either, retaining existing evidence on failure.
    streams = [safe_case_path(case, "", name) for name in output_paths[:2]]
    for src, destination in zip((out, err), streams):
        if src.exists():
            shutil.copyfile(src, destination)
        else:
            destination.write_text(error or "No output was produced for this stage attempt")
    return record
