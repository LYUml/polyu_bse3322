from logger import print
import os
import re
from typing import Dict, Any, List, Tuple, Optional, Literal
from pathlib import Path
from pydantic import BaseModel, Field
from utils import retrieve_faiss, parse_directory_structure, save_file, read_case_text
from config import Config
from openfoam_target import generation_convention, configured_openfoam_target, generation_contract
from models import ExistingCasePlan, StageOperation
from .stage_plan import OPERATION_CONTRACT
from . import get_llm_service
from .case_paths import CasePathSafetyError, safe_case_path, safe_case_relative_path


class CaseSummaryModel(BaseModel):
    case_name: str = Field(description="name of the case")
    case_domain: str = Field(description="domain of the case")
    case_category: str = Field(description="category of the case")
    case_solver: str = Field(description="Exact solver named by the user; infer only when unspecified")


class SubtaskModel(BaseModel):
    file_name: str = Field(description="Basename only, for example blockMeshDict, never system/blockMeshDict; put its parent path in folder_name")
    folder_name: str = Field(description="Case-relative parent directory, for example system; use an empty string for a case-root file")
    stage: Literal["mesh", "solver"]
    action: Literal["create", "modify"]
    changes: str = ""


class OpenFOAMPlanModel(BaseModel):
    subtasks: List[SubtaskModel] = Field(description="Input files in actual dependency order")
    operations: List[StageOperation]


def parse_requirement_to_case_info(
    user_requirement: str,
    case_stats: Dict[str, List[str]],
    *,
    llm_service: Optional[Any] = None,
    openfoam_target: str = "",
) -> Dict[str, str]:
    """
    Parse user requirements into structured case information using LLM.
    
    This function uses LLM to analyze natural language user requirements
    and extract structured case information including name, domain, category,
    and solver. The extracted values are validated against available options.
    
    Args:
        user_requirement (str): Natural language description of simulation requirements
        case_stats (Dict[str, List[str]]): Available case statistics with keys:
            - case_domain: List of available domains (e.g., ["fluid", "solid"])
            - case_category: List of available categories (e.g., ["tutorial", "advanced"])
            - case_solver: List of available solvers (e.g., ["simpleFoam", "pimpleFoam"])
    
    Returns:
        Dict[str, str]: Structured case information containing:
            - case_name (str): Parsed case name with spaces replaced by underscores
            - case_domain (str): Selected domain from available options
            - case_category (str): Selected category from available options
            - case_solver (str): Selected solver from available options
    
    Raises:
        ValueError: If LLM fails to parse requirements or returns invalid values
        RuntimeError: If LLM service is unavailable
    
    Example:
        >>> case_stats = {
        ...     "case_domain": ["fluid", "solid"],
        ...     "case_category": ["tutorial", "advanced"],
        ...     "case_solver": ["simpleFoam", "pimpleFoam"]
        ... }
        >>> result = parse_requirement_to_case_info(
        ...     "Create a simple fluid flow tutorial",
        ...     case_stats
        ... )
        >>> print(f"Case: {result['case_name']}, Solver: {result['case_solver']}")
    """
    parse_system_prompt = (
        "Please transform the following user requirement into a standard case description using a structured format."
        "The key elements should include case name, case domain, case category, and case solver."
        f"Note: case domain must be one of {case_stats.get('case_domain', [])}."
        f"Note: case category must be one of {case_stats.get('case_category', [])}."
        f"Note: case solver must be one of {case_stats.get('case_solver', [])}."
        + "\n" + generation_contract(openfoam_target)
        + "\nExtract explicit choices from the user requirement before inferring missing details. "
        "When the user names a solver available in the supplied list, preserve that exact solver name; "
        "do not substitute a more familiar solver or choose one to match a tutorial. "
        "Infer a solver only when the user has not specified one. "
    )
    parse_user_prompt = f"User requirement: {user_requirement}."
    llm_client = get_llm_service(llm_service)
    res = llm_client.invoke(parse_user_prompt, parse_system_prompt, pydantic_obj=CaseSummaryModel)
    raw_case_name = res.case_name.replace(" ", "_")
    try:
        case_name = safe_case_relative_path("", raw_case_name).name
    except CasePathSafetyError as exc:
        raise ValueError(f"Unsafe generated case name: {raw_case_name!r}") from exc
    return {
        "case_name": case_name,
        "case_domain": res.case_domain,
        "case_category": res.case_category,
        "case_solver": res.case_solver,
    }


def resolve_case_dir(
    case_name: str,
    case_dir: str = "",
    run_times: int = 1,
    run_directory: str = None
) -> str:
    """
    Resolve the case directory path based on case name and run configuration.
    
    This function determines the appropriate directory path for a case,
    handling both custom paths and default run directories with
    optional run numbering for multiple executions.
    
    Args:
        case_name (str): Name of the case (used for directory naming)
        case_dir (str, optional): Custom case directory path. If provided, this is returned directly.
        run_times (int, optional): Number of runs for this case. Defaults to 1.
        run_directory (str, optional): Base directory for runs. If None, uses default runs directory.
    
    Returns:
        str: Resolved case directory path
    
    Example:
        >>> # Custom directory
        >>> path = resolve_case_dir("test_case", case_dir="/custom/path")
        >>> print(path)  # "/custom/path"
        
        >>> # Default directory with run numbering
        >>> path = resolve_case_dir("test_case", run_times=3)
        >>> print(path)  # "/path/to/runs/test_case_3"
        
        >>> # Single run in default directory
        >>> path = resolve_case_dir("test_case")
        >>> print(path)  # "/path/to/runs/test_case"
    """
    if case_dir:
        return case_dir
    try:
        case_name = safe_case_relative_path("", case_name).name
    except CasePathSafetyError as exc:
        raise ValueError(f"Unsafe generated case name: {case_name!r}") from exc
    if run_directory is None:
        run_directory = str(Path(__file__).resolve().parents[2] / "runs")
    base_dir = str(run_directory)
    if run_times > 1:
        return os.path.join(base_dir, f"{case_name}_{run_times}")
    return os.path.join(base_dir, case_name)


class PerFileAdvice(BaseModel):
    folder_name: str = Field(description="Directory of the file relative to the case")
    file_name: str = Field(description="Basename of the input file")
    classification: Literal["reuse", "modify", "present_but_unused", "write_fresh"]
    delta: Optional[str] = Field(default=None, description="Specific user-required changes when classification is modify")


class SimilarCaseAdviceModel(BaseModel):
    pre_solver_steps: List[str] = Field(default_factory=list)
    solver: str = ""
    per_file: List[PerFileAdvice] = Field(default_factory=list)


class MeshReferenceSelection(BaseModel):
    candidate: Optional[int] = Field(description="One-based candidate number, or null when none is useful for this mesh")
    reason: str


def retrieve_mesh_reference(state, input_context):
    """Retrieve mesh guidance without selecting the simulation solver."""
    config = state["config"]
    query = state["user_requirement"] + "\nSupplied inputs:\n" + str(input_context)
    candidates = retrieve_faiss(
        "openfoam_tutorials_structure", query, topk=config.searchdocs, config=config,
    )
    if not candidates:
        return {"case": None, "content": "", "script": "", "script_reason": "No mesh reference selected", "reason": "No tutorial candidates found for mesh planning."}
    summaries = [
        {"candidate": index, **{key: item.get(key) for key in
         ("case_name", "case_domain", "case_category", "dir_structure")}}
        for index, item in enumerate(candidates, 1)
    ]
    selection = state["llm_service"].invoke(
        f"<user_requirement>{state['user_requirement']}</user_requirement>\n"
        f"<provided_inputs>{input_context}</provided_inputs>\n"
        f"<case_contents>{state.get('foamfiles') or ''}</case_contents>\n"
        f"<omitted_files>{state.get('input_omissions') or {}}</omitted_files>\n"
        f"<candidates>{summaries}</candidates>\n"
        f"<openfoam_target>{generation_convention(config)}</openfoam_target>",
        "Select one tutorial candidate useful for the requested geometry, dimensionality, "
        "mesh construction or boundary layout, or select null if none applies. "
        "Do not choose a simulation solver. This selects reference material only; "
        "it does not select the mesh backend or require copying the tutorial. "
        "User requirements and actual supplied inputs take precedence over tutorials.",
        pydantic_obj=MeshReferenceSelection,
    )
    if selection.candidate is None:
        return {"case": None, "content": "", "script": "", "script_reason": "No mesh reference selected", "reason": selection.reason}
    if not 1 <= selection.candidate <= len(candidates):
        raise ValueError(f"Mesh reference candidate out of range: {selection.candidate}")
    selected = candidates[selection.candidate - 1]
    structure = _extract_directory_structure(selected)
    detail = _retrieve_matching_details(
        selected, structure,
        max(_DETAIL_RECALL_FLOOR, config.searchdocs * _DETAIL_RECALL_MULTIPLIER),
        config=config,
    )
    identity = {key: selected.get(key) for key in
                ("case_name", "case_domain", "case_category", "case_solver")}
    if detail is None:
        return {"case": identity, "content": "", "script": "", "script_reason": "Tutorial details mismatch", "reason": "Selected tutorial details did not match its identity and directory structure."}
    script, script_reason = retrieve_matching_mesh_script(selected, structure, config)
    return {"case": identity, "content": detail["full_content"], "script": script,
            "script_reason": script_reason, "reason": selection.reason}


def retrieve_matching_mesh_script(selected, structure, config):
    query = str(_metadata_identity(selected)) + "\n" + structure
    candidates = retrieve_faiss("openfoam_allrun_scripts", query,
        topk=max(_DETAIL_RECALL_FLOOR, config.searchdocs * _DETAIL_RECALL_MULTIPLIER), config=config)
    for candidate in sorted(candidates, key=_score_value):
        if (_metadata_identity(candidate) == _metadata_identity(selected)
                and _normalise_structure(_extract_directory_structure(candidate)) == _normalise_structure(structure)):
            script = candidate["allrun_script"]
            if script and script.strip().lower() != "unknown":
                return script, "Exact tutorial identity and directory structure match"
    return "", "No script matched the selected tutorial identity and directory structure"



_DETAIL_RECALL_FLOOR = 50
_DETAIL_RECALL_MULTIPLIER = 5


def _log_top3(label: str, items: List[Dict[str, Any]]) -> None:
    print(f"{label} (top-3):")
    for i, it in enumerate(items[:3], 1):
        print(
            f"  {i}. {it.get('case_name')} | {it.get('case_domain')} | {it.get('case_category')} | {it.get('case_solver')} | score={it.get('score')}"
        )


def _rerank_candidates(
    candidates: List[Dict[str, Any]],
    case_domain: str = "",
) -> List[Dict[str, Any]]:
    def key(item: Dict[str, Any]) -> tuple:
        domain_match = int(_normalise_metadata(item.get("case_domain")) == _normalise_metadata(case_domain))
        score = item.get("score")
        score_val = 0.0 if score is None else float(score)
        return (-domain_match, score_val)

    return sorted(candidates, key=key)


def _build_advice(
    user_requirement: str,
    case_info: str,
    faiss_detailed: str,
    subtasks: List[Dict[str, str]],
    llm_service: Optional[Any] = None,
    config: Optional[Config] = None,
) -> SimilarCaseAdviceModel:
    if not faiss_detailed or not subtasks:
        return SimilarCaseAdviceModel(per_file=[
            PerFileAdvice(**task, classification="write_fresh") for task in subtasks
        ])
    system_prompt = (
        "You are a CFD expert. Classify how each reference file should be used to meet the user requirement. "
        "reuse: use its structure with only user-required changes; "
        "modify: retain its structure and describe required changes in delta; "
        "present_but_unused: the reference file does not apply, generate from scratch; "
        "write_fresh: no useful reference exists, generate from scratch. "
        "Identify required pre_solver_steps in execution order and the requested solver. "
        "User requirements and the configured OpenFOAM target take precedence over the tutorial."
    )
    user_prompt = (
        f"<user_requirement>{user_requirement}</user_requirement>\n"
        f"<case_info>{case_info}</case_info>\n"
        f"<tutorial_reference>{faiss_detailed}</tutorial_reference>\n"
        f"<subtasks>{subtasks}</subtasks>"
    )
    client = get_llm_service(llm_service, config)
    return client.invoke(user_prompt, system_prompt, pydantic_obj=SimilarCaseAdviceModel)


def retrieve_references(case_name: str,
                        case_solver: str,
                        case_domain: str,
                        case_category: str,
                        searchdocs: int = 2,
                        user_requirement: str = "",
                        config: Optional[Config] = None,
                        llm_service: Optional[Any] = None,
                        subtasks: Optional[List[Dict[str, str]]] = None) -> Tuple[str, str, str, str, SimilarCaseAdviceModel]:
    # Build case_info
    case_info = f"case name: {case_name}\ncase domain: {case_domain}\ncase category: {case_category}\ncase solver: {case_solver}"
    print("Retrieval query:\n" + case_info)

    requested_docs = max(1, int(searchdocs))
    recall_k = max(10, int(searchdocs))
    detail_recall_k = max(
        _DETAIL_RECALL_FLOOR,
        requested_docs * _DETAIL_RECALL_MULTIPLIER,
    )
    retrieval_query = case_info

    structure_kwargs: Dict[str, Any] = {"topk": recall_k}
    if config is not None:
        structure_kwargs["config"] = config
    faiss_structure_all = retrieve_faiss(
        "openfoam_tutorials_structure",
        retrieval_query,
        **structure_kwargs,
    )
    print(f"Retrieved {len(faiss_structure_all)} candidates from FAISS.")

    # Solver names determine input contracts more precisely than an inferred
    # tutorial domain. Keep exact solver matches even when that domain is wrong.
    solver_matched = [
        candidate for candidate in faiss_structure_all
        if case_solver and candidate.get("case_solver") == case_solver
    ]
    domain_matched = [
        candidate for candidate in faiss_structure_all
        if _normalise_metadata(candidate.get("case_domain")) == _normalise_metadata(case_domain)
    ]
    candidates = solver_matched or domain_matched
    _log_top3("Solver-matched structure candidates" if solver_matched else "Domain-matched structure candidates", candidates)

    if not candidates:
        print(f"No suitable similar case found for solver={case_solver}, domain={case_domain}.")
        return "", "", "", "", _build_advice(user_requirement, case_info, "", subtasks or [], llm_service, config)

    # Domain breaks ties between solver matches; semantic distance breaks the rest.
    ranked = _rerank_candidates(candidates, case_domain)
    selected = ranked[0]
    dir_structure = _extract_directory_structure(selected)
    if not dir_structure:
        print("Warning: No directory_structure found in selected similar case.")
        return "", "", "", "", _build_advice(user_requirement, case_info, "", subtasks or [], llm_service, config)

    # The structure index only contains the file tree.  Fetch the exact same
    # metadata identity from the details index before exposing file contents.
    detail = _retrieve_matching_details(
        selected,
        dir_structure,
        detail_recall_k,
        config=config,
    )
    faiss_detailed = ""
    if detail is not None:
        faiss_detailed = str(detail.get("full_content") or "")
        if _normalise_metadata(faiss_detailed) == "unknown":
            faiss_detailed = ""
        else:
            faiss_detailed = re.sub(r"\n{3,}", "\n\n", faiss_detailed)

    dir_counts = parse_directory_structure(dir_structure)
    dir_counts_str = ',\n'.join([f"There are {count} files in Directory: {directory}" for directory, count in dir_counts.items()])

    # Build allrun reference
    index_content = (
        "<index>\n"
        f"case name: {selected.get('case_name')}\n"
        f"case domain: {selected.get('case_domain')}\n"
        f"case category: {selected.get('case_category')}\n"
        f"case solver: {selected.get('case_solver')}\n"
        "</index>\n"
        f"<directory_structure>\n{dir_structure}\n</directory_structure>"
    )
    allrun_kwargs: Dict[str, Any] = {"topk": requested_docs}
    if config is not None:
        allrun_kwargs["config"] = config
    faiss_allrun = retrieve_faiss(
        "openfoam_allrun_scripts",
        index_content,
        **allrun_kwargs,
    )
    allrun_reference = "Similar cases are ordered, with smaller numbers indicating greater similarity. For example, similar_case_1 is more similar than similar_case_2, and similar_case_2 is more similar than similar_case_3.\n"
    for idx, item in enumerate(faiss_allrun):
        allrun_reference += f"<similar_case_{idx + 1}>{item['full_content']}</similar_case_{idx + 1}>\n\n\n"

    advice = _build_advice(user_requirement, case_info, faiss_detailed, subtasks or [], llm_service, config)
    return faiss_detailed, dir_structure, dir_counts_str, allrun_reference, advice


def decompose_to_subtasks(
    user_requirement: str,
    dir_structure: str,
    dir_counts_str: str,
    *,
    llm_service: Optional[Any] = None,
    openfoam_target: str = "",
) -> OpenFOAMPlanModel:
    decompose_system_prompt = (
        "You are an experienced Planner specializing in OpenFOAM projects. "
        "Your task is to break down the following user requirement into a series of smaller, manageable subtasks. "
        "For each subtask, identify the file name of the OpenFOAM input file (foamfile) and the corresponding folder name where it should be stored. "
        "Order files by actual dependencies rather than their folders. "
        "Use the supplied structured schema. For each task, declare stage as mesh or solver, "
        "action as create or modify, and concrete changes where needed. Solver includes execution scripts. "
        "Make sure that your output is valid JSON and strictly adheres to the provided schema."
        "Make sure you generate all the necessary files for the user's requirements."
        + OPERATION_CONTRACT + "\n" + generation_contract(openfoam_target)
    )

    decompose_user_prompt = (
        f"User Requirement: {user_requirement}\n\n"
        f"Reference Directory Structure (similar case): {dir_structure}\n\n{dir_counts_str}\n\n"
        "Make sure you generate all the necessary files for the user's requirements."
        "Do not include any gmsh files like .geo etc. in the subtasks."
        "Please generate the output as structured JSON."
    )

    llm_client = get_llm_service(llm_service)
    res = llm_client.invoke(decompose_user_prompt, decompose_system_prompt, pydantic_obj=OpenFOAMPlanModel)
    return res


def generate_simulation_plan(
    user_requirement: str,
    case_stats: Dict[str, List[str]],
    case_dir: str = "",
    searchdocs: int = 2,
    run_directory: str | Path | None = None,
    run_times: int = 1,
    config: Optional[Config] = None,
    llm_service: Optional[Any] = None,
) -> Dict[str, Any]:
    """
    Generate a complete simulation plan by parsing requirements and creating subtasks.
    
    This function orchestrates the entire planning process:
    1. Parse user requirements into structured case information
    2. Resolve case directory
    3. Retrieve similar case references from FAISS database
    4. Decompose requirements into manageable subtasks
    
    Args:
        user_requirement (str): Natural language description of simulation requirements
        case_stats (Dict[str, List[str]]): Available case statistics
        case_dir (str, optional): Custom case directory path
        searchdocs (int, optional): Number of similar documents to retrieve
    
    Returns:
        Dict[str, Any]: Complete plan containing:
            - case_name, case_domain, case_category, case_solver
            - case_dir: Resolved case directory
            - tutorial_reference: FAISS detailed reference
            - case_path_reference: Path to reference file
            - dir_structure_reference: Directory structure
            - allrun_reference: Allrun script references
            - subtasks: List of subtasks with file and folder names
    
    Raises:
        ValueError: If subtasks cannot be generated
        RuntimeError: If any step in the planning process fails
    """
    # Step 1: Parse user requirement to case info
    llm_service = get_llm_service(llm_service, config)
    target_convention = generation_convention(config) if config is not None else ""
    case_info = parse_requirement_to_case_info(
        user_requirement,
        case_stats,
        llm_service=llm_service,
        openfoam_target=target_convention,
    )
    case_name = case_info["case_name"]
    case_domain = case_info["case_domain"]
    case_category = case_info["case_category"]
    case_solver = case_info["case_solver"]
    
    # Step 2: Resolve case directory
    resolved_case_dir = resolve_case_dir(
        case_name=case_name,
        case_dir=case_dir or (config.case_dir if config is not None else ""),
        run_times=run_times,
        run_directory=(
            str(run_directory)
            if run_directory is not None
            else config.run_directory if config is not None else None
        ),
    )
    
    # Step 3: Retrieve references
    faiss_detailed, dir_structure, dir_counts_str, allrun_reference, _ = retrieve_references(
        case_name=case_name,
        case_solver=case_solver,
        case_domain=case_domain,
        case_category=case_category,
        searchdocs=searchdocs,
        user_requirement=user_requirement,
        config=config,
        llm_service=llm_service,
    )
    
    # Step 4: Decompose to subtasks.
    operation_plan = decompose_to_subtasks(
        user_requirement + f"\n<solver_reference>{faiss_detailed}</solver_reference>\n"
        + f"<solver_script_reference>{allrun_reference}</solver_script_reference>",
        dir_structure,
        dir_counts_str,
        llm_service=llm_service,
        openfoam_target=target_convention,
    )
    
    subtasks = [task.model_dump() for task in operation_plan.subtasks]
    if len(subtasks) == 0:
        raise ValueError("Failed to generate subtasks.")
    
    advice = _build_advice(
        user_requirement,
        f"{case_info}; OpenFOAM target: {target_convention}",
        faiss_detailed,
        subtasks,
        llm_service,
    )

    # Prepare reference file path
    case_path_reference = os.path.join(resolved_case_dir, "similar_case.txt")
    
    return {
        "case_name": case_name,
        "case_domain": case_domain,
        "case_category": case_category,
        "case_solver": case_solver,
        "case_dir": resolved_case_dir,
        "tutorial_reference": faiss_detailed,
        "case_path_reference": case_path_reference,
        "dir_structure_reference": dir_structure,
        "allrun_reference": allrun_reference,
        "subtasks": subtasks,
        "similar_case_advice": advice,
    }


def prepare_solver_context(state):
    """Choose solver metadata and retrieve solver references after mesh handoff."""
    config = state["config"]
    reference_path = str(safe_case_path(state["case_dir"], "", "similar_case.txt"))
    requirement = (
        state["user_requirement"]
        + f"\n<actual_mesh>{state.get('mesh_info') or {}}</actual_mesh>"
        + f"\n<existing_case>{state.get('foamfiles') or ''}</existing_case>"
        + f"\n<omitted_files>{state.get('input_omissions') or {}}</omitted_files>"
        + f"\n<mesh_boundary_plan>{state.get('mesh_boundary_plan') or []}</mesh_boundary_plan>"
        + f"\n<mesh_reference_source>{state['mesh_reference']['case']}</mesh_reference_source>"
        + "\nChoose the solver for this physical problem. Preserve existing physics "
          "unless changes are requested. The mesh has already been prepared. "
          "Distinguish planned boundary roles and tutorial assumptions from actual mesh facts."
    )
    metadata = parse_requirement_to_case_info(
        requirement, state["case_stats"], llm_service=state["llm_service"],
        openfoam_target=generation_convention(config),
    )
    reference, structure, dir_counts_str, scripts, advice = retrieve_references(
        **metadata, searchdocs=config.searchdocs,
        user_requirement=state["user_requirement"], config=config,
        llm_service=state["llm_service"],
    )
    save_file(reference_path, f"{reference}\n\n{scripts}")
    return {
        **metadata, "case_name": state["case_name"],
        "case_info": "\n".join(f"{key}: {value}" for key, value in metadata.items()),
        "tutorial_reference": reference, "dir_structure_reference": structure,
        "dir_counts_str": dir_counts_str,
        "case_path_reference": reference_path,
        "allrun_reference": scripts,
        "similar_case_advice": advice.model_dump() if hasattr(advice, "model_dump") else advice,
    }


DEFAULT_IMPORTED_REQUIREMENT = (
    "Run the supplied OpenFOAM case while preserving its existing physical definition. "
    "Diagnose and repair technical problems only when execution requires it."
)



def _model_dump(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        return value.model_dump()
    if isinstance(value, dict):
        return value
    raise TypeError(f"Expected a structured model response, got {type(value).__name__}")


def plan_imported_case(state: dict[str, Any]) -> dict[str, Any]:
    """Plan physical file changes and solver execution after mesh preparation."""
    target = configured_openfoam_target(state.get("config")) or (state.get("case_context") or {}).get("platform")

    prompt = (
        "You are planning work on an existing OpenFOAM case. Return structured routing decisions. "
        "Set requires_input_writer only when files must be created or changed, and requires_meshing "
        "when further mesh operations are needed. The graph prepares the mesh first, "
        "then modifies files if needed, then runs the case. A complete case with no requested changes "
        "must set both flags to false. Preserve existing physical conditions unless explicitly changed. "
        "If a required physical condition cannot be inferred, return failed and explain the missing information in reason. "
        "When requires_input_writer is true, target_files must list the files to create or modify and the required changes. "
        "Explain the requested modifications in reason.\n"
        f"<user_requirement>{state.get('user_requirement', '')}</user_requirement>\n"
        f"<dir_structure>{state.get('dir_structure') or {}}</dir_structure>\n"
        f"<foamfiles>{state.get('foamfiles')}</foamfiles>\n"
        f"<omitted_files>{state.get('input_omissions') or {}}</omitted_files>\n"
        f"<error_logs>{state.get('error_logs') or []}</error_logs>\n"
        f"<review_analysis>{state.get('review_analysis') or ''}</review_analysis>\n"
        f"<custom_mesh_path>{state.get('custom_mesh_path') or ''}</custom_mesh_path>\n"
        f"<openfoam_target>{target}</openfoam_target>"
        f"\n<actual_mesh>{state.get('mesh_info') or {}}</actual_mesh>\n"
        f"<mesh_execution>{state.get('mesh_execution')}</mesh_execution>\n"
        f"<mesh_boundary_plan>{state.get('mesh_boundary_plan') or []}</mesh_boundary_plan>\n"
        f"<mesh_reference_source>{(state.get('mesh_reference') or {}).get('case')}</mesh_reference_source>\n"
        f"<selected_solver>{state.get('case_solver') or ''}</selected_solver>\n"
        f"<reference>{state.get('tutorial_reference') or ''}</reference>\n"
        f"<solver_script_reference>{state.get('allrun_reference') or ''}</solver_script_reference>\n"
        "Check whether the actual mesh can represent the user-required physics and planned "
        "boundary roles. Actual patch_bounds are measured mesh facts; planned locations "
        "may differ. Tutorial defaults are assumptions, not user requirements. "
        "If incompatible, request mesh-stage changes and preserve pending solver work. "
        "The mesh has already been prepared. Plan only physical fields and solver "
        "file changes using the actual patches. Adapt existing mesh-tool startup dictionaries "
        "to the requested physics with explicit modify tasks where needed. Meshing handles all mesh files, "
        "geometry, mesh scripts and mesh commands. Declare each target file stage as "
        "mesh or solver; solver includes execution scripts. If further mesh changes "
        "are needed, set requires_meshing even when only commands on existing files are "
        "needed, and explain those operations in reason. Include any file changes "
        "explicitly with stage mesh for Meshing to handle. "
        "Declare the complete runnable solver-only remainder of the existing Allrun as "
        "literal script operations, when present. "
        "Preserve shell setup, helper functions, solver arguments, necessary physical "
        "field preparation and solver-parallel decomposition. Remove mesh generation, "
        "conversion, checks, modifications and cleanup, including inside helper functions. "
        "Use the selected solver, adapting controlDict and Allrun if required by the "
        "requested physics. When no Allrun exists, declare its literal ordered solver commands "
        "and necessary shell setup in operations."
    )
    llm = state.get("llm_service")
    response = llm.invoke(
        prompt,
        OPERATION_CONTRACT + " Plan the minimum work required for this existing case. Declare each file stage "
        "as mesh or solver, including execution scripts in solver.",
        pydantic_obj=ExistingCasePlan,
    )
    plan = _model_dump(response)
    status = plan.get("status", "failed")
    targets = plan.get("target_files") or []
    if status == "ready" and plan.get("requires_input_writer") and not targets:
        return {
            "workflow_status": "failed",
            "requires_meshing": False,
            "requires_input_writer": False,
            "termination_reason": "Planner must specify target_files before requesting file changes.",
        }
    return {
        "solver_operations": plan["operations"],
        "workflow_status": "running" if status == "ready" else status,
        "requires_meshing": bool(plan.get("requires_meshing")) or (
            any(t["stage"] == "mesh" for t in targets)
        ),
        "requires_input_writer": bool(plan.get("requires_input_writer")),
        "input_writer_mode": "rewrite",
        "review_analysis": plan.get("reason") or "Apply the requested changes to the existing case.",
        "rewrite_plan": {"target_files": targets} if targets else None,
        "termination_reason": None if status == "ready" else plan.get("reason") or status,
    }


def _normalise_metadata(value: Any) -> str:
    return str(value or "").strip().casefold()


def _normalise_structure(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()






def _score_value(item: Dict[str, Any]) -> float:
    score = item.get("score")
    if score is None:
        return float("inf")
    try:
        return float(score)
    except (TypeError, ValueError):
        return float("inf")


def _metadata_identity(item: Dict[str, Any]) -> tuple[str, str, str, str]:
    return tuple(
        str(item.get(key) or "").strip()
        for key in ("case_name", "case_domain", "case_category", "case_solver")
    )


def _extract_directory_structure(item: Dict[str, Any]) -> str:
    structure = item.get("dir_structure")
    if structure and _normalise_metadata(structure) != "unknown":
        structure = str(structure).strip()
        block = re.fullmatch(r"<directory_structure>(.*?)</directory_structure>",
                             structure, re.DOTALL | re.IGNORECASE)
        return block[1].strip() if block else structure

    full_content = str(item.get("full_content") or "")
    match = re.search(
        r"<directory_structure>(.*?)</directory_structure>",
        full_content,
        re.DOTALL | re.IGNORECASE,
    )
    return match.group(1).strip() if match else ""


def _retrieve_matching_details(
    selected: Dict[str, Any],
    dir_structure: str,
    recall_k: int,
    config: Optional[Config] = None,
) -> Optional[Dict[str, Any]]:
    """Fetch details for the exact case selected from the structure index."""
    detail_query = (
        "<index>\n"
        f"case name: {selected.get('case_name')}\n"
        f"case domain: {selected.get('case_domain')}\n"
        f"case category: {selected.get('case_category')}\n"
        f"case solver: {selected.get('case_solver')}\n"
        "</index>\n"
        f"<directory_structure>\n{dir_structure}\n</directory_structure>"
    )

    kwargs: Dict[str, Any] = {"topk": recall_k}
    if config is not None:
        kwargs["config"] = config
    candidates = retrieve_faiss(
        "openfoam_tutorials_details",
        detail_query,
        **kwargs,
    )

    selected_identity = _metadata_identity(selected)
    exact_matches = [
        candidate
        for candidate in candidates
        if _metadata_identity(candidate) == selected_identity
    ]
    if not exact_matches:
        print(
            "Warning: Details index did not return the exact case selected from "
            "the structure index; skipping tutorial contents."
        )
        return None

    target_structure = _normalise_structure(dir_structure)
    exact_structure_matches = [
        candidate
        for candidate in exact_matches
        if _normalise_structure(_extract_directory_structure(candidate))
        == target_structure
    ]
    if not exact_structure_matches:
        print(
            "Warning: Details index returned matching case metadata but not the "
            "same directory structure; skipping tutorial contents."
        )
        return None

    return min(exact_structure_matches, key=_score_value)
