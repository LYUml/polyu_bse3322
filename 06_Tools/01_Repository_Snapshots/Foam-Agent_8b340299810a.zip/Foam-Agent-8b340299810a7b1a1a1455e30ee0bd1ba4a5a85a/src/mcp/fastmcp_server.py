"""FastMCP-based OpenFOAM Agent Server.

This module provides a modern MCP server implementation using FastMCP,
exposing OpenFOAM simulation capabilities through clean, well-typed interfaces.
"""

from copy import deepcopy
import os
import json
import subprocess
import zlib
from typing import Any, Dict, List, Literal, Optional

from fastmcp import FastMCP, Context
from pydantic import BaseModel, Field

# Import existing services
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.plan import (
    resolve_case_dir,
    retrieve_references,
    generate_simulation_plan,
)
from services.input_writer import initial_write, normalise_initial_subtasks
from services.stage_plan import check_file_targets
from services.execution_logs import check_execution_outputs
from services import get_llm_service
from services.run_local import run_allrun_and_collect_errors
from services.solver_execution import read_case_application

from utils import FoamPydantic, read_case_foamfiles, scan_case_directory
from services.case_inputs import read_case_inputs
from services.review import generate_rewrite_plan, review_error_logs
from services.static_review import StaticReviewReport, review_case_inputs
from translation.esi_translator import convert_case_to_esi_if_needed
from services.visualization import visualize_case
from services.output_safety import prepare_output_directory
from config import Config
from logger import setup_logging, LOG_FILENAMES
from .dispatch import run_tool
from openfoam_target import (
    runtime_openfoam_target,
    database_path_for_config,
    generation_convention,
    normalise_openfoam_target,
    require_target_corpus,
    uses_legacy_esi_translation,
)


# Global configuration
global_config = Config()


# Create FastMCP server
mcp = FastMCP(
    name="Foam-Agent",
    version="2.0.0",
    instructions="""
Foam-Agent is a multi-agent framework that automates the entire OpenFOAM-based CFD simulation workflow from a single natural language prompt.
By managing the full pipeline—from meshing and case setup to execution and post-processing—Foam-Agent dramatically lowers the expertise barrier for Computational Fluid Dynamics.

IMPORTANT: Foam-Agent generates cases using **Foundation OpenFOAM v10** conventions by default. If
`FOAMAGENT_OPENFOAM_FORK=esi` is set, generated input files are translated to ESI OpenFOAM
(openfoam.com) naming and dictionary conventions on a best-effort basis before they are returned.
This legacy fork setting is not the native v2006 target.

Native ESI/OpenCFD v2006 is supported by setting
`FOAMAGENT_OPENFOAM_TARGET=esi-v2006`. In that mode, planning and generation use the isolated
v2006 corpus and native conventions, local execution sources and validates the v2006 runtime,
and review/fix uses the same target convention. The native target bypasses the legacy translator.
It requires a matching ESI v2006 runtime and target corpus.

Existing-case import is exposed through the run_case tool. It uses the shared StateGraph workflow,
including target detection, planning, controlled execution, review, and targeted repair.
"""
)


# ============================================================================
# Tool: plan
# ============================================================================

class PlanRequest(BaseModel):
    """Request to plan simulation structure."""
    user_requirement: str = Field(description="User requirements for the simulation")


class PlanResponse(BaseModel):
    """Response from simulation planning."""
    subtasks: List[Dict[str, str]] = Field(description="List of subtasks with file and folder information")
    case_name: str = Field(description="Generated case name")
    case_solver: str = Field(description="OpenFOAM solver to use")
    case_domain: str = Field(description="Simulation domain (e.g., 'fluid', 'solid')")
    case_category: str = Field(description="Case category (e.g., 'tutorial', 'advanced')")
    tutorial_reference: str = Field(default="", description="Retrieved target-version tutorial evidence for generation and review")
    allrun_reference: str = Field(default="", description="Retrieved execution examples for generation and review")

def _plan(
    request: PlanRequest,
    notify
) -> PlanResponse:
    try:
        notify('info', "Planning simulation structure from user requirements")
        require_target_corpus(global_config)
        
        # Load case statistics, available domains, categories, and solvers
        case_stats_path = database_path_for_config(global_config) / "raw" / "openfoam_case_stats.json"
        with open(case_stats_path, 'r') as f:
            case_stats = json.load(f)
        
        # Generate simulation plan
        plan_data = generate_simulation_plan(
            user_requirement=request.user_requirement,
            case_stats=case_stats,
            case_dir="",  # Will be resolved later
            searchdocs=global_config.searchdocs,
            config=global_config,
        )
        
        notify('info', f"Generated {len(plan_data['subtasks'])} subtasks")
        
        # Keep legacy path keys while preserving the planner's file instructions.
        subtasks = [
            {"file": task["file_name"], "folder": task["folder_name"],
             **{key: task[key] for key in ("stage", "action", "changes") if key in task}}
            for task in plan_data["subtasks"]
        ]
        
        return PlanResponse(
            subtasks=subtasks,
            case_name=plan_data["case_name"],
            case_solver=plan_data["case_solver"],
            case_domain=plan_data["case_domain"],
            case_category=plan_data["case_category"],
            tutorial_reference=plan_data.get("tutorial_reference") or "",
            allrun_reference=plan_data.get("allrun_reference") or "",
        )
        
    except Exception as e:
        notify('error', f"Failed to plan simulation: {str(e)}")
        raise



@mcp.tool(name="plan")
async def plan(
    request: PlanRequest,
    ctx: Context
) -> PlanResponse:
    """Plan the simulation structure by analyzing requirements and generating subtasks.

    This function uses AI to break down user requirements into manageable subtasks
    for OpenFOAM file generation.
    """
    return await run_tool(_plan, request, ctx)


# ============================================================================
# Tool: input_writer
# ============================================================================

class GenerateFilesRequest(BaseModel):
    """Request to generate OpenFOAM files."""
    case_name: str = Field(description="Case name (from plan response)")
    subtasks: List[Dict[str, str]] = Field(description="List of subtasks to generate files for")
    user_requirement: str = Field(description="User requirements")
    case_solver: str = Field(description="OpenFOAM solver to use")
    case_domain: str = Field(description="Simulation domain")
    case_category: str = Field(description="Case category")
    execution_mode: Optional[Literal["careful", "fast"]] = Field(
        default=None, description="Generation preset; standalone static_review is a separate explicit step",
    )
    input_writer_generation_mode: Optional[Literal["sequential_dependency", "parallel_no_context"]] = Field(
        default=None, description="Explicit override of the preset's file generation strategy",
    )
    overwrite_output: bool = Field(
        default=False,
        description="Allow replacing an existing Foam-Agent-owned output directory.",
    )


class GenerateFilesResponse(BaseModel):
    """Response from file generation."""
    case_dir: str = Field(description="Path to the case directory")
    foamfiles: FoamPydantic = Field(description="Generated OpenFOAM files with metadata")
    allrun_script: str = Field(description="Path to the generated Allrun script")

def _input_writer(
    request: GenerateFilesRequest,
    notify
) -> GenerateFilesResponse:
    try:
        notify('info', f"Generating OpenFOAM files for case: {request.case_name}")
        config = deepcopy(global_config)
        if request.execution_mode is not None:
            config.execution_mode = request.execution_mode
        if request.input_writer_generation_mode is not None:
            config.input_writer_generation_mode = request.input_writer_generation_mode
        require_target_corpus(global_config)

        # Resolve case directory
        case_dir = resolve_case_dir(
            case_name=request.case_name,
            case_dir=config.case_dir,
            run_times=config.run_times,
            run_directory=config.run_directory,
        )
        notify('info', f"Case directory: {case_dir}")

        # Build case info from request
        case_info = {
            "case_name": request.case_name,
            "case_solver": request.case_solver,
            "case_domain": request.case_domain,
            "case_category": request.case_category
        }

        notify('info', f"Case info: {case_info}")

        # Convert subtasks format from {file, folder} to {file_name, folder_name}
        converted_subtasks = []
        for st in request.subtasks:
            if isinstance(st, dict):
                # Handle both formats: {file, folder} or {file_name, folder_name}
                file_name = st.get("file_name") or st.get("file")
                folder_name = st.get("folder_name", st.get("folder"))
                if file_name and folder_name is not None:
                    converted_subtasks.append({
                        "file_name": file_name,
                        "folder_name": folder_name,
                        **{key: st[key] for key in ("stage", "action", "changes") if key in st},
                    })
                else:
                    raise ValueError(f"Invalid subtask format: {st}. Must have 'file'/'file_name' and 'folder'/'folder_name'")
            else:
                raise ValueError(f"Invalid subtask type: {type(st)}. Expected dict, got {st}")

        converted_subtasks = normalise_initial_subtasks(converted_subtasks)
        targets = ["/".join(part for part in (st['folder_name'], st['file_name']) if part)
                   for st in converted_subtasks]
        target_errors = check_file_targets(None, [*targets, *([] if 'Allrun' in targets else ['Allrun'])])
        target_errors.extend(check_execution_outputs(LOG_FILENAMES, targets))
        if target_errors:
            raise ValueError(str(target_errors))
        prepare_output_directory(case_dir, overwrite=request.overwrite_output)
        setup_logging(case_dir)

        # Retrieve references
        client = get_llm_service(config=config)
        tutorial_reference, _, _, allrun_reference, similar_case_advice = retrieve_references(
            case_name=case_info["case_name"],
            case_solver=case_info["case_solver"],
            case_domain=case_info["case_domain"],
            case_category=case_info["case_category"],
            searchdocs=global_config.searchdocs,
            config=global_config,
            user_requirement=request.user_requirement,
            subtasks=converted_subtasks,
            llm_service=client,
        )

        notify('info', f"converted_subtasks: {converted_subtasks}")

        def progress_callback(current: int, total: int, message: str) -> None:
            notify("report_progress", current, total, message)

        result = initial_write(
            case_dir=case_dir,
            subtasks=converted_subtasks,
            user_requirement=request.user_requirement,
            tutorial_reference=tutorial_reference,
            case_solver=request.case_solver,
            case_info=str(case_info),
            allrun_reference=allrun_reference,
            database_path=str(database_path_for_config(global_config)),
            searchdocs=global_config.searchdocs,
            similar_case_advice=similar_case_advice,
            progress_callback=progress_callback,
            openfoam_fork=generation_convention(global_config),
            generation_mode=config.generation_mode,
            config=config,
            llm_service=client,
        )
        if result.get('error_logs'):
            raise RuntimeError(str(result['error_logs']))

        notify('info', f"result: {result}")

        # Get foamfiles from result
        foamfiles = result.get("foamfiles")
        if not foamfiles:
            raise ValueError("No foamfiles returned from initial_write")

        # Convert to ESI if needed
        if uses_legacy_esi_translation(global_config):
            convert_case_to_esi_if_needed(case_dir, global_config)
        
        # Rescan the directory and foam files to reflect any translations
        dir_structure = scan_case_directory(case_dir)
        foamfiles = read_case_foamfiles(case_dir, dir_structure)

        if not foamfiles:
            raise ValueError("No foamfiles returned after translation")

        allrun_script = os.path.join(case_dir, "Allrun")

        num_files = len(foamfiles.list_foamfile) if hasattr(foamfiles, "list_foamfile") else 0
        notify('info', f"Generated {num_files} OpenFOAM files in {case_dir}")

        return GenerateFilesResponse(
            case_dir=case_dir,
            foamfiles=foamfiles,
            allrun_script=allrun_script
        )

    except Exception as e:
        notify('error', f"Failed to generate OpenFOAM files: {str(e)}")
        raise



@mcp.tool(name="input_writer")
async def input_writer(
    request: GenerateFilesRequest,
    ctx: Context
) -> GenerateFilesResponse:
    """Generate OpenFOAM input files based on subtasks and requirements.

    This function creates all necessary OpenFOAM input files (system/, constant/, 0/).
    It generates Foundation v10 files by default. Explicit native ESI v2006 uses
    its own corpus and conventions; the separate FOAMAGENT_OPENFOAM_FORK=esi
    compatibility mode still applies best-effort post-generation translation.
    """
    return await run_tool(
        _input_writer, request, ctx,
        case_dir=lambda: resolve_case_dir(
            request.case_name, case_dir=global_config.case_dir,
            run_times=global_config.run_times, run_directory=global_config.run_directory,
        ),
    )


# ============================================================================
# Tool: run
# ============================================================================

class RunSimulationRequest(BaseModel):
    """Request to run local simulation."""
    case_dir: str = Field(description="Path to the case directory")
    timeout: int = Field(default=3600, description="Timeout in seconds")


class RunSimulationResponse(BaseModel):
    """Response from simulation run."""
    status: str = Field(description="Run status: 'success' or 'failed'")
    errors: List[str] = Field(description="List of errors found")
    log_files: Dict[str, str] = Field(description="Paths to log files")

def _run(
    request: RunSimulationRequest,
    notify
) -> RunSimulationResponse:
    try:
        notify('info', f"Running simulation in directory: {request.case_dir}")
        
        # Validate case directory exists
        if not os.path.exists(request.case_dir):
            raise ValueError(f"Case directory does not exist: {request.case_dir}")
        
        error_logs = run_allrun_and_collect_errors(
            case_dir=request.case_dir,
            timeout=request.timeout,
            max_retries=3,
            openfoam_target=runtime_openfoam_target(global_config),
        )
        
        # Convert error logs to strings if they're dictionaries
        errors = []
        for err in error_logs:
            if isinstance(err, dict):
                # Format: "file: error_content"
                file_name = err.get("file", "unknown")
                error_content = err.get("error_content", str(err))
                diagnostic_context = err.get("diagnostic_context")
                errors.append(f"{file_name}: {error_content}" +
                              (f"\n\n{diagnostic_context}" if diagnostic_context else ""))
            else:
                errors.append(str(err))
        
        # Prepare log file paths (not content)
        log_files = {}
        out_path = os.path.join(request.case_dir, 'Allrun.out')
        err_path = os.path.join(request.case_dir, 'Allrun.err')
        
        if os.path.exists(out_path):
            log_files['Allrun.out'] = out_path
        
        if os.path.exists(err_path):
            log_files['Allrun.err'] = err_path
        
        status = "success" if not errors else "failed"
        
        notify('info', f"Simulation {status} with {len(errors)} error(s)")
        
        return RunSimulationResponse(
            status=status,
            errors=errors,
            log_files=log_files
        )
            
    except Exception as e:
        notify('error', f"Failed to run simulation: {str(e)}")
        raise



@mcp.tool(name="run")
async def run(
    request: RunSimulationRequest,
    ctx: Context
) -> RunSimulationResponse:
    """Run the OpenFOAM simulation locally.

    This function executes the Allrun script and collects any errors. Foundation
    v10 is the default runtime. An explicit ESI v2006 target sources and checks
    its native runtime; legacy FOAMAGENT_OPENFOAM_FORK=esi remains a separately
    translated compatibility path.
    """
    return await run_tool(_run, request, ctx, case_dir=request.case_dir, log_output=True)


# ============================================================================
# Tool: review
# ============================================================================

class ReviewRequest(BaseModel):
    """Request to review simulation errors."""
    case_dir: str = Field(description="Path to the case directory")
    errors: List[str] = Field(description="List of error messages from simulation")
    user_requirement: str = Field(description="Original user requirements")


class ReviewResponse(BaseModel):
    """Response from simulation review."""
    analysis: str = Field(description="Analysis of simulation errors")

def _review(
    request: ReviewRequest,
    notify
) -> ReviewResponse:
    try:
        notify('info', f"Reviewing errors for case directory: {request.case_dir}")
        
        # Validate case directory exists
        if not os.path.exists(request.case_dir):
            raise ValueError(f"Case directory does not exist: {request.case_dir}")

        try:
            case_solver = read_case_application(
                request.case_dir, openfoam_target=runtime_openfoam_target(global_config),
                timeout=global_config.max_time_limit,
            )
        except (OSError, UnicodeError, EOFError, zlib.error, ValueError,
                subprocess.CalledProcessError, subprocess.TimeoutExpired, RuntimeError) as error:
            details = "\n".join(str(part) for part in
                                (error, getattr(error, "stdout", ""), getattr(error, "stderr", "")) if part)
            tutorial_reference = (
                "No solver tutorial reference was retrieved: the application in system/controlDict "
                f"could not be established: {details}. "
                "Diagnose the supplied files and errors without assuming a solver."
            )
        else:
            require_target_corpus(global_config)
            tutorial_reference, _, _, _, _ = retrieve_references(
                case_name=os.path.basename(os.path.normpath(request.case_dir)),
                case_solver=os.path.basename(case_solver),
                case_domain="",
                case_category="",
                searchdocs=global_config.searchdocs,
                config=global_config,
            )
        
        # Read current foamfiles from case directory for review context
        notify('info', "Reading OpenFOAM files for review context...")
        foamfiles, omitted = read_case_inputs(request.case_dir)
        notify('info', f"Read {len(foamfiles.list_foamfile)} file(s) for review")
        
        # Review results - directly call review_error_logs
        client = get_llm_service(config=global_config)
        review_content, _ = review_error_logs(
            tutorial_reference=tutorial_reference,
            foamfiles=foamfiles,
            error_logs=request.errors,
            user_requirement=request.user_requirement,
            history_text=None,
            openfoam_target=generation_convention(global_config),
            omitted_files=omitted,
            llm_service=client,
        )
        
        notify('info', f"Review completed, found {len(request.errors)} error(s)")
        
        # Format response (suggestions and issues are empty as review_error_logs only returns analysis)
        return ReviewResponse(
            analysis=review_content
        )
        
    except Exception as e:
        notify('error', f"Failed to review results: {str(e)}")
        raise



@mcp.tool(name="review")
async def review(
    request: ReviewRequest,
    ctx: Context
) -> ReviewResponse:
    """Review simulation errors and suggest improvements.

    This function analyzes simulation errors and provides suggestions for fixes.
    It uses Foundation v10 references by default, or an isolated ESI v2006 corpus
    when that native target is selected. Legacy translated ESI cases remain
    best-effort.
    """
    return await run_tool(_review, request, ctx)


# ============================================================================
# Tool: apply_fixes
# ============================================================================

class ApplyFixesRequest(BaseModel):
    """Request to apply fixes to an OpenFOAM case based on review analysis."""
    case_dir: str = Field(description="Path to the OpenFOAM case directory")
    error_logs: List[str] = Field(description="List of error log messages from simulation")
    review_analysis: str = Field(description="Review analysis with fix suggestions from the review tool. Must be provided.")
    user_requirement: str = Field(description="Original user requirements or simulation description for context")


class ApplyFixesResponse(BaseModel):
    """Response from applying fixes."""
    updated_files: List[str] = Field(description="List of file paths that were updated")
    status: str = Field(description="Fix application status ('ok' or 'no_changes')")

def _apply_fixes(
    request: ApplyFixesRequest,
    notify
) -> ApplyFixesResponse:
    try:
        notify('info', f"Applying fixes for case directory: {request.case_dir}")
        
        # Validate case directory exists
        if not os.path.exists(request.case_dir):
            raise ValueError(f"Case directory does not exist: {request.case_dir}")
        
        # Validate review_analysis is provided
        if not request.review_analysis or request.review_analysis.strip() == "":
            raise ValueError(
                "review_analysis is required. Please call the 'review' tool first "
                "to get review analysis, then provide it to this tool."
            )
        
        notify('info', "Rewriting OpenFOAM files based on review analysis...")
        
        # This standalone tool retains an explicit, file-scoped repair plan.
        from services.input_writer import rewrite_files

        foamfiles, omitted = read_case_inputs(request.case_dir)
        client = get_llm_service(config=global_config)
        rewrite_plan = generate_rewrite_plan(
            foamfiles=foamfiles,
            error_logs=request.error_logs,
            review_analysis=request.review_analysis,
            user_requirement=request.user_requirement,
            openfoam_target=generation_convention(global_config),
            llm_service=client,
        )

        result = rewrite_files(
            case_dir=request.case_dir,
            error_logs=request.error_logs,
            review_analysis=request.review_analysis,
            rewrite_plan=rewrite_plan,
            user_requirement=request.user_requirement,
            foamfiles=foamfiles,
            openfoam_fork=generation_convention(global_config),
            script_phase="all",
            omitted_files=omitted,
            static_repair=not request.error_logs,
            llm_service=client,
        )
        if (result.get('rewrite_plan') or {}).get('target_files') and result.get('error_logs'):
            raise RuntimeError(str(result['error_logs']))

        written_files = [
            os.path.join(request.case_dir, relative_path)
            for relative_path in result.get("updated_files", [])
        ]
        
        status = "ok" if written_files else "no_changes"
        
        notify('info', f"Successfully applied fixes. Updated {len(written_files)} file(s)")
        
        return ApplyFixesResponse(
            updated_files=written_files,
            status=status
        )
        
    except Exception as e:
        notify('error', f"Failed to apply fixes: {str(e)}")
        raise



@mcp.tool(name="apply_fixes")
async def apply_fixes(
    request: ApplyFixesRequest,
    ctx: Context
) -> ApplyFixesResponse:
    """Apply fixes to the OpenFOAM case files based on review analysis.

    This tool rewrites OpenFOAM files to fix errors identified during review.
    It must be called after the 'review' tool has provided analysis.
    Fix generation follows the active target convention: Foundation v10 by default,
    native ESI v2006 when `FOAMAGENT_OPENFOAM_TARGET=esi-v2006` is selected, and
    ESI generation conventions when the legacy `FOAMAGENT_OPENFOAM_FORK=esi` mode is used.

    The tool directly calls rewrite_files which handles:
    - Reading current foamfiles and directory structure from case_dir
    - Using LLM to generate corrected file contents based on review_analysis
    - Writing updated files back to the case directory

    Workflow:
    1. First call 'review' tool to get review_analysis
    2. Then call 'apply_fixes' with the review_analysis to rewrite files

    Args:
        request: ApplyFixesRequest containing:
            - case_dir: Path to the OpenFOAM case directory
            - error_logs: List of error messages from simulation
            - review_analysis: Analysis and fix suggestions from review tool (required)
            - user_requirement: Original user requirements (optional)

    Returns:
        ApplyFixesResponse with list of updated files and status

    Raises:
        ValueError: If case directory does not exist or review_analysis is empty
        RuntimeError: If fix application fails

    Example:
        # Two-step workflow (review first, then fix)
        review_resp = await review(case_dir, errors, user_requirement)
        fix_resp = await apply_fixes(case_dir, errors, review_resp.analysis, user_requirement)
    """
    return await run_tool(_apply_fixes, request, ctx, case_dir=request.case_dir, log_output=True)


# ============================================================================
# Tool: static_review
# ============================================================================

class StaticReviewRequest(BaseModel):
    case_dir: str = Field(pattern=r"\S", description="Case directory to inspect without executing or modifying it")
    user_requirement: str = Field(description="Original simulation requirement to check against")
    tutorial_reference: str = Field(default="", description="Existing target-version tutorial reference from plan")
    allrun_reference: str = Field(default="", description="Existing target-version execution examples from plan")

def _static_review(request: StaticReviewRequest, notify) -> StaticReviewReport:
    notify('info', f"Statically reviewing case: {request.case_dir}")
    report, _ = review_case_inputs(
        case_dir=request.case_dir,
        user_requirement=request.user_requirement,
        openfoam_fork=generation_convention(global_config),
        tutorial_reference=request.tutorial_reference,
        allrun_reference=request.allrun_reference,
        config=global_config,
    )
    return report



@mcp.tool(name="static_review")
async def static_review(request: StaticReviewRequest, ctx: Context) -> StaticReviewReport:
    """Read current inputs and report definite errors and warnings before running."""
    return await run_tool(_static_review, request, ctx)


# ============================================================================
# Tool: run_case
# ============================================================================

class RunCaseRequest(BaseModel):
    """Request to import and run an existing OpenFOAM case."""

    case_path: str = Field(description="Existing OpenFOAM case directory or ZIP archive")
    output_dir: str = Field(description="Destination for the read-only original, writable work tree, and report")
    user_requirement: str = Field(
        default="",
        description="Optional requested changes; empty preserves a complete case before running it",
    )
    case_subdir: Optional[str] = Field(
        default=None,
        description="Relative case directory when the source contains multiple OpenFOAM cases",
    )
    custom_mesh_path: Optional[str] = Field(
        default=None,
        description="Optional Gmsh .msh file (ASCII 2.2 format)",
    )
    openfoam_target: Optional[str] = Field(
        default=None,
        description="Optional explicit native target: foundation-v10 or esi-v2006",
    )
    overwrite_output: bool = Field(
        default=False,
        description="Allow replacement of an existing Foam-Agent-owned output directory",
    )
    execution_mode: Optional[Literal["careful", "fast"]] = Field(
        default=None, description="careful (default) reviews before initial mesh and solver execution; fast skips static review",
    )
    input_writer_generation_mode: Optional[Literal["sequential_dependency", "parallel_no_context"]] = Field(
        default=None, description="Explicit file generation override, independent of static review",
    )
    max_static_review_retries: Optional[int] = Field(
        default=None, ge=0, description="Static repair rounds shared by both initial stages (default 10); independent of max_loop",
    )


class RunCaseResponse(BaseModel):
    """Terminal state of the shared existing-case workflow."""

    status: str = Field(description="Workflow status: success, partial_success or failed")
    message: Optional[str] = Field(default=None, description="Workflow completion summary")
    visualization_error: Optional[str] = Field(default=None, description="Visualization failure details")
    case_dir: str = Field(description="Writable imported case directory")
    report_dir: Optional[str] = Field(description="Directory containing import and workflow reports")
    errors: List[Any] = Field(description="Terminal execution or workflow errors")
    termination_reason: Optional[str] = Field(description="Reason the workflow stopped, if it failed")
    static_review: Optional[StaticReviewReport] = Field(
        default=None, description="Aggregated initial mesh/solver static reviews; not repeated after runtime repairs",
    )

def _run_case(request: RunCaseRequest, notify) -> RunCaseResponse:
    try:
        if not request.case_path.strip():
            raise ValueError("case_path is required.")
        if not request.output_dir.strip():
            raise ValueError("output_dir is required.")

        config = deepcopy(global_config)
        config.case_dir = request.output_dir
        config.overwrite_case_dir = request.overwrite_output
        for name in ("execution_mode", "input_writer_generation_mode", "max_static_review_retries"):
            value = getattr(request, name)
            if value is not None:
                setattr(config, name, value)
        if request.openfoam_target is not None:
            config.openfoam_target = normalise_openfoam_target(request.openfoam_target)

        notify('info', f"Importing and running existing case: {request.case_path}")

        # Import lazily so starting the MCP server does not execute CLI-only code.
        from main import main as run_workflow

        result = run_workflow(
            request.user_requirement,
            config,
            request.custom_mesh_path,
            case_path=request.case_path,
            case_subdir=request.case_subdir,
        )

        termination_reason = result.get("termination_reason")
        failed = result.get("workflow_status") == "failed" or bool(termination_reason)
        status = "partial_success" if result.get("workflow_status") == "partial_success" else ("failed" if failed else "success")
        notify('info', f"Existing-case workflow finished with status: {status}")
        return RunCaseResponse(
            status=status,
            message=result.get("workflow_message"),
            visualization_error=result.get("visualization_error"),
            case_dir=result.get("case_dir") or request.output_dir,
            report_dir=result.get("case_import_report_dir"),
            errors=list(result.get("error_logs") or []),
            termination_reason=termination_reason,
            static_review=result.get("static_review_report"),
        )
    except Exception as e:
        notify('error', f"Failed to run existing case: {str(e)}")
        raise



@mcp.tool(name="run_case")
async def run_case(request: RunCaseRequest, ctx: Context) -> RunCaseResponse:
    """Import an existing case or ZIP and execute the shared repair workflow."""
    return await run_tool(_run_case, request, ctx, case_dir=request.output_dir)


# ============================================================================
# Tool: visualization
# ============================================================================

class VisualizationRequest(BaseModel):
    """Request to generate visualization."""
    case_dir: str = Field(description="Path to the case directory")
    quantity: str = Field(description="Quantity to visualize (e.g., 'velocity', 'pressure')")
    visualization_type: str = Field(default="pyvista", description="Visualization type")


class VisualizationResponse(BaseModel):
    """Response from visualization generation."""
    artifacts: List[str] = Field(description="List of generated visualization files")
    script: str = Field(description="Visualization script")

def _visualization(
    request: VisualizationRequest,
    notify
) -> VisualizationResponse:
    try:
        notify('info', f"Generating visualization for case directory: {request.case_dir}")
        
        # Validate case directory exists
        if not os.path.exists(request.case_dir):
            raise ValueError(f"Case directory does not exist: {request.case_dir}")
        
        result = visualize_case(
            request.case_dir,
            request.quantity,
            max_loop=max(1, min(global_config.max_loop, 2)),
            timeout_s=max(1, min(global_config.max_time_limit, 180)),
            config=global_config,
        )
        visualization_result = result["pyvista_visualization"]
        if not visualization_result["success"]:
            raise RuntimeError(visualization_result["error"])
        artifacts = result["plot_outputs"]
        script = visualization_result["script"]
        
        notify('info', f"Generated {len(artifacts)} visualization artifact(s)")
        
        return VisualizationResponse(
            artifacts=artifacts,
            script=script
        )
        
    except Exception as e:
        notify('error', f"Failed to generate visualization: {str(e)}")
        raise



@mcp.tool(name="visualization")
async def visualization(
    request: VisualizationRequest,
    ctx: Context
) -> VisualizationResponse:
    """Generate visualization for the simulation results.

    This function creates visualization artifacts using PyVista for the active
    OpenFOAM target's output. Runtime and corpus selection are handled by the
    preceding workflow tools; native ESI v2006 uses the same target selection as
    planning, generation, execution, and review.
    """
    return await run_tool(_visualization, request, ctx, case_dir=request.case_dir, log_output=True)



if __name__ == "__main__":
    from src.mcp.cli import main

    main(server=mcp, default_transport="http", default_host="localhost")
